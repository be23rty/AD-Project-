@echo off
setlocal
cd /d "%~dp0"
title News Bias & Framing Analyzer

echo ===============================================
echo   News Bias ^& Framing Analyzer
echo   One-click launcher
echo ===============================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set "PYTHON=python"
    ) else (
        echo Python was not found on this computer.
        echo Install Python 3.10 or newer from https://www.python.org/downloads/
        echo Make sure "Add Python to PATH" is enabled during installation.
        pause
        exit /b 1
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating a private Python environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 (
        echo Failed to create the Python environment.
        pause
        exit /b 1
    )
) else (
    echo [1/3] Existing Python environment found.
)

echo [2/3] Installing/updating required packages...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
    echo.
    echo Dependency installation failed. Check your internet connection and try again.
    pause
    exit /b 1
)

echo [3/3] Starting the application...
start "News Bias Analyzer Browser" cmd /c "timeout /t 2 /nobreak ^>nul ^& start http://127.0.0.1:5000"
".venv\Scripts\python.exe" app.py

pause
endlocal
