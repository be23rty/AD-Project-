# News Bias & Framing Analyzer — V8.11.6 full-article analysis

This version changes the collection layer from **NewsAPI-only** to a multi-source pipeline.

## What changed

- Search for an event/topic from the website.
- Search results are collected from:
  - Google News RSS search
  - direct publisher RSS feeds (BBC, Guardian, Al Jazeera, NYT, The Hindu, Indian Express, NDTV, Times of India, India Today, News18)
  - NewsAPI when `NEWSAPI_KEY` is configured
- Duplicate stories are removed.
- Results are shown before analysis, so the user chooses which stories to compare.
- Selecting stories and pressing **Analyze selected** attempts to fetch the article page and extract its text.
- If a publisher blocks extraction, the RSS/NewsAPI description is used as a fallback.
- Existing manual article comparison remains available.
- Trending topics now use Google News RSS and do not require a NewsAPI key.

## Run on Windows — one click

Double-click **`run.bat`** in the project folder. It will:

1. Check that Python is installed.
2. Create a local `.venv` Python environment the first time.
3. Install the required packages.
4. Start Flask.
5. Open the app automatically in your browser at `http://127.0.0.1:5000`.

The first launch can take a little longer because dependencies are installed. Keep the black terminal window open while using the website; close it to stop the server.

### Manual run

```bash
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000`.

### Optional NewsAPI

Set `NEWSAPI_KEY` if you want an additional API source. The app still searches RSS sources without it.

PowerShell:

```powershell
$env:NEWSAPI_KEY = "your-key"
python app.py
```

## Important source/usage note

Publisher RSS feeds have their own terms. For example, The Indian Express and NDTV describe their RSS feeds as personal/non-commercial and include attribution/copyright conditions. Google News RSS is useful for prototyping, but its feed pages also state usage restrictions. For a public/commercial deployment, replace or supplement these feeds with sources whose licenses/terms permit the intended use.

The application stores headlines, metadata and links and attempts best-effort text extraction only when the selected article is analyzed. It does not bypass paywalls.

## Next stage

The current analyzer is still the original heuristic sentiment/framing layer. The planned upgrade is target-specific analysis:

`event → competing entities/sides → stance toward each side → framing → evidence → cross-source comparison`

## V8.1 historical-event fix

Historical searches now support an explicit **Incident date**. The app uses that date to query a dated Google News window (45 days before through 45 days after the event) and filters returned articles by their publication date. This prevents current anniversary/retrospective stories from replacing the original coverage.

The app automatically recognizes the **22 April 2025 Pahalgam terror attack** when the query contains Pahalgam plus attack/terror/militant terms. Users can override the detected date with the date picker.

Article cards show a human-readable publication date, and the neutral context baseline is constructed only from the date-filtered coverage.


## V8.2 expanded media

The collector supports additional publisher domains plus Reddit and YouTube. Reddit posts are treated as community signals, not newsroom reporting. YouTube search is optional and requires `YOUTUBE_API_KEY`; the YouTube Data API supplies video title, description, channel and publication date. The official YouTube search API supports date filtering through `publishedAfter`/`publishedBefore`. Reddit's API supports search listings and time ranges, and this project filters returned posts to the historical incident window.

Optional environment variable:
- `YOUTUBE_API_KEY=...`

Reddit works through public search endpoints where available. YouTube is omitted automatically when no API key is configured.

## V8.9 dynamic LLM comparison intent

The comparison system is now LLM-driven instead of using a hardcoded list of historical events or country pairs. When `GEMINI_API_KEY` is configured, the app uses Gemini 3.8 Flash to infer the search subject and suggest comparison targets from the user's wording and retrieved headlines. No event/topic mapping such as "World War 1 -> Allies/Central Powers" is hardcoded.

Set these optional environment variables:

```powershell
$env:GEMINI_API_KEY = "your-key"
$env:GEMINI_MODEL = "gemini-3.8-flash"
python app.py
```

The user can always edit the two comparison sides manually; the manual choice is what the stance graph analyzes. If no Gemini key is configured, the app still searches and the manual comparison picker remains available, with only explicit query syntax used for suggestions.

## V8.10 — Dynamic event competitors, dimensions and overall framing share

The analyzer now treats broad searches as **event analysis**, not merely keyword search.
With `GEMINI_API_KEY` configured, it uses a two-pass Gemini intent layer:

1. Understand the event before retrieval.
2. Retrieve coverage.
3. Re-check the retrieved headlines/snippets to identify the actual competitors.
4. Offer dynamic 2- or 3-side comparisons.
5. Detect independent framing dimensions when the event genuinely contains them, such as
   territorial/geographic, military/security, political, humanitarian, legal, economic,
   religious/identity, or gameplay/performance framing.
6. Produce a separate stance graph for each detected dimension.
7. Produce an **Overall media framing share** pie chart aggregated from the selected articles.

No event-specific competitor table is hardcoded. For example, a query such as `Telangana
 elections` can dynamically resolve to the relevant election and its competing parties,
while a war, sports match, or other event can resolve to its own sides.

The pie chart is explicitly a **media-language signal**, not a public-opinion poll and not
proof that an outlet endorses a side.


## V8.11.5 selected-analysis reliability fixes

- The comparison picker preselects the first dynamically suggested comparison when no targets have been selected, while remaining editable.
- Selected article analysis now falls back to available snippets/headlines when full-text extraction fails or an article has no fetchable URL.
- This prevents a failed publisher page extraction from unnecessarily blocking analysis; limited-text articles should be treated as lower-evidence results.


## V8.11.6 — full-article analysis reliability

- Selected-article analysis now requires substantial article-body text (at least 350 characters).
- Headline-only and short RSS-description fallback is disabled for bias/framing scores.
- Article extraction checks publisher JSON-LD `articleBody`, article/main paragraph containers, and full-content RSS/Atom fields where available.
- The NLP sentiment, framing, target-specific stance, and neutral-baseline calculations use the extracted article body, not the headline.
- Gemini article stance receives the extracted body only and is instructed to assess evidence across the supplied body.
- The results page reports how many articles and body characters were analysed.
- If fewer than two selected articles yield enough full text, the app returns a clear warning rather than generating a misleading comparison.

**Limitations:** Some publishers block automated access, require subscriptions, or render article text only through scripts. Those stories are excluded from selected-article scoring when the body cannot be extracted. The extractor supports common HTML/JSON-LD/RSS patterns but cannot guarantee access to every publisher or recover paywalled content.
