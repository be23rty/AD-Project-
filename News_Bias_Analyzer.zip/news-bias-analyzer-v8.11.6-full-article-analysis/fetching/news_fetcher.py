"""Multi-source news collection for the News Bias & Framing Analyzer.

Collection strategy:
1. Google News RSS search: broad discovery without an API key.
2. Curated publisher RSS feeds: direct publisher coverage where available.
3. NewsAPI: optional extra source when NEWSAPI_KEY is configured.

The collector normalizes all sources into the same article shape so the
analysis layer does not care where an article came from.
"""
import html
import json
import os
import re
import urllib.parse
from datetime import timedelta
from collections import Counter
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

import requests
from bs4 import BeautifulSoup

NEWSAPI_KEY = os.environ.get("NEWSAPI_KEY", "")
NEWSAPI_EVERYTHING_URL = "https://newsapi.org/v2/everything"
NEWSAPI_TOP_HEADLINES_URL = "https://newsapi.org/v2/top-headlines"
YOUTUBE_API_KEY = os.environ.get("YOUTUBE_API_KEY", "")
YOUTUBE_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search"
REDDIT_SEARCH_URL = "https://www.reddit.com/search.json"
REDDIT_COMMENTS_URL = "https://www.reddit.com/comments/{post_id}.json"
YOUTUBE_COMMENTS_URL = "https://www.googleapis.com/youtube/v3/commentThreads"

HEADERS = {
    "User-Agent": (
        "NewsBiasAnalyzer/2.0 (educational project) "
        "Mozilla/5.0 AppleWebKit/537.36 Chrome/154 Safari/537.36"
    ),
    "Accept": "application/rss+xml, application/xml, text/xml, text/html;q=0.9, */*;q=0.8",
}

GOOGLE_NEWS_RSS = "https://news.google.com/rss/search"

# These are public publisher feeds. Feed availability can change, so a broken
# feed is skipped rather than taking down the whole search.
DIRECT_RSS_SOURCES = {
    "BBC": "https://feeds.bbci.co.uk/news/world/rss.xml",
    "The Guardian": "https://www.theguardian.com/international/rss",
    "Al Jazeera": "https://www.aljazeera.com/xml/rss/all.xml",
    "The New York Times": "https://rss.nytimes.com/services/xml/rss/nyt/World.xml",
    "The Hindu": "https://www.thehindu.com/feeder/default.rss",
    "The Indian Express": "https://indianexpress.com/section/india/feed/",
    "NDTV": "https://feeds.feedburner.com/ndtvnews-top-stories",
    "Times of India": "https://timesofindia.indiatimes.com/rssfeedstopstories.cms",
    "Hindustan Times": "https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml",
    "India Today": "https://www.indiatoday.in/rss/home",
    "News18": "https://www.news18.com/rss/india.xml",
    "Reuters": "https://feeds.reuters.com/reuters/topNews",
    "Associated Press": "https://feeds.apnews.com/apf-topnews",
    "NPR": "https://feeds.npr.org/1001/rss.xml",
    "CNN": "http://rss.cnn.com/rss/edition.rss",
    "Washington Post": "https://feeds.washingtonpost.com/rss/national",
    "DW": "https://rss.dw.com/rdf/rss-en-all",
    "France 24": "https://www.france24.com/en/rss",
    "The Wire": "https://thewire.in/rss",
    "Scroll.in": "https://scroll.in/rss",
    "Deccan Herald": "https://www.deccanherald.com/rss-feeds",
    "The Telegraph India": "https://www.telegraphindia.com/rss",
    "The Quint": "https://www.thequint.com/feed",
    "ThePrint": "https://theprint.in/feed/",
}

TOPIC_FEEDS = {
    "general": "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en",
    "business": "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-IN&gl=IN&ceid=IN:en",
    "technology": "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN:en",
    "entertainment": "https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=en-IN&gl=IN:en",
    "sports": "https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-IN&gl=IN:en",
    "health": "https://news.google.com/rss/headlines/section/topic/HEALTH?hl=en-IN&gl=IN:en",
    "science": "https://news.google.com/rss/headlines/section/topic/SCIENCE?hl=en-IN&gl=IN:en",
}

TOPIC_CATEGORIES = list(TOPIC_FEEDS.keys())


class NewsFetchError(Exception):
    pass


def _clean(value):
    value = html.unescape(value or "")
    value = BeautifulSoup(value, "html.parser").get_text(" ", strip=True)
    return re.sub(r"\s+", " ", value).strip()


def _parse_date(value):
    if not value:
        return ""
    return value.strip()


def _xml_child_text(parent, local_name):
    """Read RSS extension elements such as content:encoded by local name."""
    for child in list(parent):
        if child.tag.split("}")[-1].lower() == local_name.lower():
            return child.text or ""
    return ""


def _parse_rss(xml_bytes, fallback_source=""):
    """Parse RSS/Atom and preserve full-content fields when publishers provide them."""
    root = ET.fromstring(xml_bytes)
    items = []
    rss_items = root.findall(".//item")
    if rss_items:
        for item in rss_items:
            title = _clean(item.findtext("title"))
            link = _clean(item.findtext("link"))
            description = _clean(item.findtext("description"))
            content_html = _xml_child_text(item, "encoded") or _xml_child_text(item, "content")
            content_text = _clean(content_html)
            pub = _parse_date(item.findtext("pubDate"))
            source_el = item.find("source")
            source = _clean(source_el.text if source_el is not None else fallback_source)
            source_url = source_el.attrib.get("url", "") if source_el is not None else ""
            items.append({
                "source": source or fallback_source, "headline": title,
                "snippet": description, "feed_content": content_text,
                "url": link, "published_at": pub, "source_url": source_url,
            })
        return items

    ns = {"atom": "http://www.w3.org/2005/Atom"}
    for entry in root.findall(".//atom:entry", ns):
        title = _clean(entry.findtext("atom:title", namespaces=ns))
        summary = _clean(entry.findtext("atom:summary", namespaces=ns))
        content_html = entry.findtext("atom:content", namespaces=ns) or ""
        updated = _clean(entry.findtext("atom:updated", namespaces=ns))
        link = ""
        for link_el in entry.findall("atom:link", ns):
            if link_el.attrib.get("rel", "alternate") == "alternate":
                link = link_el.attrib.get("href", "")
                break
        items.append({
            "source": fallback_source, "headline": title, "snippet": summary,
            "feed_content": _clean(content_html), "url": link,
            "published_at": updated, "source_url": "",
        })
    return items


def _fetch_feed(url, fallback_source=""):
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()
        return _parse_rss(response.content, fallback_source=fallback_source)
    except (requests.RequestException, ET.ParseError, ValueError):
        return []


EVENT_DATE_HINTS = [
    (re.compile(r"\bpahalgam\b.*\b(terror|attack|attacks|militant)\b|\b(terror|attack|attacks|militant)\b.*\bpahalgam\b", re.I), "2025-04-22"),
]

def infer_event_date(query):
    """Infer a known incident date or an explicit YYYY-MM-DD/known-year date."""
    q = (query or "").strip()
    m = re.search(r"\b(20\d{2})[-/](0?[1-9]|1[0-2])[-/](0?[1-9]|[12]\d|3[01])\b", q)
    if m:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    for pattern, date in EVENT_DATE_HINTS:
        if pattern.search(q):
            return date
    return ""

def _historical_bounds(event_date, before_days=45, after_days=45):
    try:
        d = datetime.strptime(event_date, "%Y-%m-%d").date()
    except ValueError:
        return "", ""
    return (d - timedelta(days=before_days)).isoformat(), (d + timedelta(days=after_days + 1)).isoformat()

def _google_search_url(query, days=None, event_date=None):
    if event_date:
        start, end = _historical_bounds(event_date)
        q = f"{query} after:{start} before:{end}" if start and end else query
    else:
        q = query if days is None else f"{query} when:{days}d"
    return (
        f"{GOOGLE_NEWS_RSS}?q={urllib.parse.quote_plus(q)}"
        "&hl=en-IN&gl=IN&ceid=IN:en"
    )


def _article_key(article):
    # URLs are strongest; title+source handles feeds that redirect through an
    # aggregator and articles with tracking parameters.
    url = (article.get("url") or "").split("?")[0].rstrip("/").lower()
    if url:
        return url
    title = re.sub(r"[^a-z0-9]+", " ", article.get("headline", "").lower()).strip()
    source = article.get("source", "").lower()
    return f"{source}|{title}"


SEARCH_INTENT_WORDS = {
    "hit", "flop", "success", "successful", "failure", "fail", "failed",
    "good", "bad", "pros", "cons", "pro", "con", "support", "oppose",
    "vs", "versus", "against", "or", "whether", "compare", "comparison",
    "is", "was", "are", "did", "does", "the", "a", "an", "of", "for",
    "latest", "news", "analysis", "review", "reviews", "movie", "movies",
    "film", "films", "box", "office", "collection", "collections",
}

def _query_tokens(query):
    return [t.lower() for t in re.findall(r"[\w'-]+", query) if len(t) > 2]

def _search_focus(query):
    """Extract the subject of the search, excluding comparison instructions.

    Examples:
      'animal movie hit or flop' -> ['animal']
      'Peddi hit or flop'        -> ['peddi']
      'Russia vs Ukraine'        -> ['russia', 'ukraine']
      'Pahalgam terror attack'   -> ['pahalgam', 'terror', 'attack']
    """
    q = re.sub(r"\s+", " ", (query or "").lower()).strip()
    # Explicit pair: retain both sides as the search subject.
    m = re.search(r"^(.{1,80}?)\s+(?:vs\.?|versus|against)\s+(.{1,80}?)(?:\?|$)", q, re.I)
    if m:
        q = f"{m.group(1)} {m.group(2)}"
    # Remove comparison phrases, but leave the actual subject intact.
    q = re.sub(r"\b(?:hit|flop|success|successful|failure|fail|failed|good|bad)\b", " ", q)
    q = re.sub(r"\b(?:or|vs|versus|against|whether|compare|comparison)\b", " ", q)
    tokens = [t for t in re.findall(r"[\w'-]+", q) if len(t) > 2 and t not in SEARCH_INTENT_WORDS]
    return tokens


def _term_present(text, token):
    # Allow simple plurals/inflections while avoiding substring false positives.
    return bool(re.search(r"(?<![a-z0-9])" + re.escape(token) + r"(?:s|es|ed|ing)?(?![a-z0-9])", text, re.I))


def _relevance(article, query, focus_tokens=None):
    tokens = focus_tokens if focus_tokens is not None else _query_tokens(query)
    if not tokens:
        return 0
    headline = (article.get("headline", "") or "").lower()
    snippet = (article.get("snippet", "") or "").lower()
    score = 0
    for token in tokens:
        if _term_present(headline, token):
            score += 3
        elif _term_present(snippet, token):
            score += 1
    return score


def _has_search_focus(article, focus_tokens):
    if not focus_tokens:
        return True
    text = f"{article.get('headline', '')} {article.get('snippet', '')}".lower()
    return any(_term_present(text, token) for token in focus_tokens)


def _google_results(query, limit=80, event_date=None):
    # Deliberately search the long-term Google News index. The app is a
    # historical framing tool, so restricting discovery to the last 7 days
    # would hide the original reporting of older incidents.
    articles = _fetch_feed(_google_search_url(query, event_date=event_date), "Google News")
    # Google News provides a publisher name in <source>, which our parser uses.
    return articles[:limit]


def _direct_results(query, focus_tokens=None):
    results = []
    with ThreadPoolExecutor(max_workers=min(10, len(DIRECT_RSS_SOURCES))) as pool:
        futures = {
            pool.submit(_fetch_feed, url, source): source
            for source, url in DIRECT_RSS_SOURCES.items()
        }
        for future in as_completed(futures):
            source = futures[future]
            try:
                feed_items = future.result()
            except Exception:
                feed_items = []
            for article in feed_items:
                score = _relevance(article, query, focus_tokens)
                if score > 0 and _has_search_focus(article, focus_tokens or []):
                    article["source"] = source
                    article["relevance"] = score
                    results.append(article)
    return results


def _newsapi_results(query, limit=80):
    if not NEWSAPI_KEY:
        return []
    params = {
        "q": query,
        "language": "en",
        "sortBy": "relevancy",
        "pageSize": min(limit, 100),
        "apiKey": NEWSAPI_KEY,
    }
    try:
        response = requests.get(NEWSAPI_EVERYTHING_URL, params=params, timeout=15)
        if response.status_code == 401:
            return []
        if response.status_code == 429:
            return []
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError):
        return []

    if payload.get("status") != "ok":
        return []

    results = []
    for article in payload.get("articles", []):
        source = (article.get("source") or {}).get("name", "").strip()
        title = (article.get("title") or "").strip()
        url = article.get("url", "")
        if not source or not title or not url:
            continue
        results.append({
            "source": source,
            "headline": title,
            "snippet": (article.get("description") or "").strip(),
            "url": url,
            "published_at": article.get("publishedAt", ""),
            "source_url": "",
            "provider": "NewsAPI",
        })
    return results


SOURCE_DOMAINS = {
    "BBC": "bbc.com",
    "The Guardian": "theguardian.com",
    "Al Jazeera": "aljazeera.com",
    "The New York Times": "nytimes.com",
    "The Hindu": "thehindu.com",
    "The Indian Express": "indianexpress.com",
    "NDTV": "ndtv.com",
    "Times of India": "timesofindia.indiatimes.com",
    "Hindustan Times": "hindustantimes.com",
    "India Today": "indiatoday.in",
    "News18": "news18.com",
    "Reuters": "reuters.com",
    "Associated Press": "apnews.com",
    "NPR": "npr.org",
    "CNN": "cnn.com",
    "Washington Post": "washingtonpost.com",
    "DW": "dw.com",
    "France 24": "france24.com",
    "The Wire": "thewire.in",
    "Scroll.in": "scroll.in",
    "Deccan Herald": "deccanherald.com",
    "The Telegraph India": "telegraphindia.com",
    "The Quint": "thequint.com",
    "ThePrint": "theprint.in",
    "Reddit": "reddit.com",
    "YouTube": "youtube.com",
}

AVAILABLE_SOURCES = list(SOURCE_DOMAINS.keys())

def _source_matches(article_source, wanted):
    a = (article_source or "").strip().lower()
    w = (wanted or "").strip().lower()
    if not a or not w:
        return False
    aliases = {
        "times of india": ["times of india", "toi"],
        "hindustan times": ["hindustan times", "ht"],
        "the hindu": ["the hindu"],
        "the indian express": ["the indian express", "indian express"],
        "bbc": ["bbc", "bbc news"],
        "the guardian": ["the guardian", "guardian"],
        "the new york times": ["the new york times", "new york times", "nytimes"],
        "associated press": ["associated press", "ap news", "ap"],
        "washington post": ["washington post", "washingtonpost"],
        "france 24": ["france 24", "france24"],
        "the wire": ["the wire", "thewire"],
        "scroll.in": ["scroll.in", "scroll"],
        "deccan herald": ["deccan herald", "deccanherald"],
        "the telegraph india": ["telegraph india", "telegraphindia"],
        "the quint": ["the quint", "thequint"],
        "theprint": ["theprint", "the print"],
        "reddit": ["reddit"],
        "youtube": ["youtube", "youtu.be"],
    }
    names = aliases.get(w, [w])
    return any(name in a for name in names)

def _date_metadata(value):
    """Return ISO date + human label without requiring python-dateutil."""
    raw = (value or "").strip()
    if not raw:
        return "", "Date unavailable"
    dt = None
    try:
        from email.utils import parsedate_to_datetime
        dt = parsedate_to_datetime(raw)
    except Exception:
        pass
    if dt is None:
        try:
            candidate = raw.replace("Z", "+00:00")
            dt = datetime.fromisoformat(candidate)
        except Exception:
            pass
    if dt is None:
        return raw, raw
    return dt.date().isoformat(), dt.strftime("%d %b %Y")


def _decorate_dates(articles):
    for article in articles:
        iso, label = _date_metadata(article.get("published_at", ""))
        article["published_date"] = iso
        article["published_label"] = label
    return articles



def _reddit_results(query, limit=30, event_date=None):
    """Fetch public Reddit posts matching the event. Posts are community signals, not newsroom reporting."""
    params = {"q": query, "sort": "relevance", "t": "all", "limit": min(limit, 100), "raw_json": 1}
    try:
        response = requests.get(
            REDDIT_SEARCH_URL, params=params,
            headers={**HEADERS, "User-Agent": "NewsBiasAnalyzer/2.0 educational project"}, timeout=15
        )
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError):
        return []
    start = end = None
    if event_date:
        try:
            d = datetime.strptime(event_date, "%Y-%m-%d").date()
            start = datetime.combine(d - timedelta(days=45), datetime.min.time()).timestamp()
            end = datetime.combine(d + timedelta(days=46), datetime.min.time()).timestamp()
        except ValueError:
            pass
    out=[]
    for child in (payload.get("data") or {}).get("children", []):
        data=child.get("data") or {}
        created=float(data.get("created_utc") or 0)
        if start is not None and not (start <= created < end):
            continue
        title=_clean(data.get("title"))
        if not title: continue
        permalink=data.get("permalink", "")
        url="https://www.reddit.com"+permalink if permalink.startswith("/") else data.get("url", "")
        published=datetime.utcfromtimestamp(created).strftime("%Y-%m-%dT%H:%M:%SZ") if created else ""
        out.append({"source":"Reddit", "headline":title, "snippet":_clean(data.get("selftext"))[:1200],
                    "url":url, "published_at":published, "source_url":url,
                    "provider":"Reddit", "media_type":"community", "reddit_id":data.get("id", ""),
                    "subreddit":_clean(data.get("subreddit_name_prefixed") or data.get("subreddit"))})
    return out


def _youtube_results(query, limit=20, event_date=None):
    """Optional YouTube search. Requires YOUTUBE_API_KEY; title/description/date are analyzable metadata."""
    if not YOUTUBE_API_KEY:
        return []
    params={"part":"snippet", "q":query, "type":"video", "order":"relevance",
            "maxResults":min(limit,50), "key":YOUTUBE_API_KEY}
    if event_date:
        try:
            d=datetime.strptime(event_date, "%Y-%m-%d")
            params["publishedAfter"]=(d-timedelta(days=45)).strftime("%Y-%m-%dT00:00:00Z")
            params["publishedBefore"]=(d+timedelta(days=46)).strftime("%Y-%m-%dT00:00:00Z")
        except ValueError: pass
    try:
        response=requests.get(YOUTUBE_SEARCH_URL, params=params, headers=HEADERS, timeout=15)
        response.raise_for_status(); payload=response.json()
    except (requests.RequestException, ValueError):
        return []
    out=[]
    for item in payload.get("items", []):
        sn=item.get("snippet") or {}; vid=(item.get("id") or {}).get("videoId")
        if not vid: continue
        out.append({"source":"YouTube", "headline":_clean(sn.get("title")),
                    "snippet":_clean(sn.get("description")),
                    "url":f"https://www.youtube.com/watch?v={vid}",
                    "published_at":sn.get("publishedAt", ""), "source_url":"",
                    "provider":"YouTube Data API", "media_type":"video",
                    "channel":_clean(sn.get("channelTitle")), "video_id":vid})
    return out


def _reddit_comment_rows(post_id, limit=6):
    if not post_id:
        return []
    url = REDDIT_COMMENTS_URL.format(post_id=urllib.parse.quote(post_id))
    try:
        response = requests.get(url, params={"raw_json": 1, "sort": "top", "limit": min(limit, 20)},
                                headers={**HEADERS, "User-Agent": "NewsBiasAnalyzer/2.0 educational project"}, timeout=15)
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError, TypeError):
        return []
    if not isinstance(payload, list) or len(payload) < 2:
        return []
    rows = []
    def walk(children, depth=0):
        for child in children or []:
            if len(rows) >= limit:
                return
            data = child.get("data") or {}
            body = _clean(data.get("body"))
            if body and body not in {"[deleted]", "[removed]"}:
                rows.append({
                    "text": body[:1600],
                    "score": int(data.get("score") or 0),
                    "author": _clean(data.get("author") or "anonymous"),
                    "comment_id": data.get("id", ""),
                })
            replies = data.get("replies")
            if isinstance(replies, dict):
                walk((replies.get("data") or {}).get("children", []), depth + 1)
    walk((payload[1].get("data") or {}).get("children", []))
    rows.sort(key=lambda x: x.get("score", 0), reverse=True)
    return rows[:limit]


def _youtube_comment_rows(video_id, limit=6):
    if not YOUTUBE_API_KEY or not video_id:
        return []
    params = {"part": "snippet", "videoId": video_id, "order": "relevance",
              "maxResults": min(limit, 100), "textFormat": "plainText", "key": YOUTUBE_API_KEY}
    try:
        response = requests.get(YOUTUBE_COMMENTS_URL, params=params, headers=HEADERS, timeout=15)
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError):
        return []
    rows = []
    for item in payload.get("items", []):
        top = (((item.get("snippet") or {}).get("topLevelComment") or {}).get("snippet") or {})
        body = _clean(top.get("textDisplay") or top.get("textOriginal"))
        if not body:
            continue
        rows.append({
            "text": body[:1600],
            "score": int(top.get("likeCount") or 0),
            "author": _clean(top.get("authorDisplayName") or "anonymous"),
            "comment_id": item.get("id", ""),
        })
    return rows


def collect_people_perspectives(query, articles=None, event_date=None, max_reddit_posts=8, max_youtube_videos=5):
    """Collect public community reactions separately from newsroom coverage.

    Reddit post/comment text and YouTube comments are treated as anecdotal public
    perspectives, not representative polling. YouTube requires an API key.
    """
    articles = articles or []
    reddit_posts = [a for a in articles if a.get("source") == "Reddit"][:max_reddit_posts]
    youtube_videos = [a for a in articles if a.get("source") == "YouTube"][:max_youtube_videos]

    if not reddit_posts and not youtube_videos:
        # Keep this usable even when the source picker excludes community media.
        with ThreadPoolExecutor(max_workers=2) as pool:
            rf = pool.submit(_reddit_results, query, max_reddit_posts, event_date)
            yf = pool.submit(_youtube_results, query, max_youtube_videos, event_date)
            try: reddit_posts = rf.result()
            except Exception: reddit_posts = []
            try: youtube_videos = yf.result()
            except Exception: youtube_videos = []

    perspectives = []
    for post in reddit_posts:
        comments = _reddit_comment_rows(post.get("reddit_id", ""), 6)
        # The post itself is useful perspective context even if comments are unavailable.
        if post.get("snippet"):
            comments.insert(0, {"text": post.get("snippet"), "score": 0, "author": "post author", "comment_id": ""})
        perspectives.append({
            "platform": "Reddit", "community": post.get("subreddit") or "Reddit",
            "headline": post.get("headline", ""), "url": post.get("url", ""),
            "published_at": post.get("published_at", ""), "comments": comments[:6]
        })

    for video in youtube_videos:
        comments = _youtube_comment_rows(video.get("video_id", ""), 6)
        perspectives.append({
            "platform": "YouTube", "community": video.get("channel") or "YouTube",
            "headline": video.get("headline", ""), "url": video.get("url", ""),
            "published_at": video.get("published_at", ""), "comments": comments
        })

    return perspectives

def search_news(query: str, max_results: int = 30, sources=None, event_date=None):
    """Return candidate stories, optionally restricted to selected publishers."""
    if not query.strip():
        return []

    selected = [s for s in (sources or []) if s in AVAILABLE_SOURCES]
    event_date = event_date or infer_event_date(query)
    focus_tokens = _search_focus(query)

    # When the user picks publishers, query Google News directly with each
    # publisher domain as well as the direct RSS feeds. This prevents a source
    # from disappearing simply because it ranked below the first page of a
    # broad search.
    if selected:
        google_queries = []
        for source in selected:
            domain = SOURCE_DOMAINS.get(source)
            google_queries.append(f"{query} site:{domain}" if domain else query)
        with ThreadPoolExecutor(max_workers=min(8, len(selected) + 1)) as pool:
            futures = [pool.submit(_google_results, q, 80, event_date) for q in google_queries]
            futures.append(pool.submit(_direct_results, query, focus_tokens))
            if "Reddit" in selected: futures.append(pool.submit(_reddit_results, query, 30, event_date))
            if "YouTube" in selected: futures.append(pool.submit(_youtube_results, query, 20, event_date))
            combined = []
            for future in futures:
                try:
                    combined.extend(future.result())
                except Exception:
                    pass
        combined = [a for a in combined if any(_source_matches(a.get("source"), s) for s in selected)]
    else:
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [
                pool.submit(_google_results, query, 80, event_date),
                pool.submit(_direct_results, query, focus_tokens),
                pool.submit(_newsapi_results, query),
                pool.submit(_reddit_results, query, 30, event_date),
                pool.submit(_youtube_results, query, 20, event_date),
            ]
            combined = []
            for future in futures:
                try:
                    combined.extend(future.result())
                except Exception:
                    pass

    # Re-rank against the actual subject of the search, not generic comparison
    # words such as "hit", "flop", "movie", "success", etc. This prevents a
    # query like "animal movie hit or flop" from returning every article that
    # merely contains the words "movie" and "hit".
    filtered_combined = []
    for article in combined:
        focus_score = _relevance(article, query, focus_tokens)
        if focus_tokens and focus_score <= 0:
            continue
        article["relevance"] = max(article.get("relevance", 0), focus_score)
        if article.get("provider") == "NewsAPI":
            article["relevance"] += 0.25
        elif article.get("source") != "Google News":
            article["relevance"] += 0.1
        if article.get("media_type") in {"community", "video"}:
            article["relevance"] += 0.05
        filtered_combined.append(article)
    combined = filtered_combined

    deduped = {}
    for article in combined:
        key = _article_key(article)
        if key not in deduped or article.get("relevance", 0) > deduped[key].get("relevance", 0):
            deduped[key] = article

    articles = list(deduped.values())
    articles.sort(key=lambda a: a.get("relevance", 0), reverse=True)

    # In historical mode, discard current-feed items that fall outside the
    # incident window. This is the critical guard that prevents a 2026 article
    # about the first anniversary from replacing the original 2025 coverage.
    if event_date:
        start, end = _historical_bounds(event_date)
        filtered = []
        for article in articles:
            iso, label = _date_metadata(article.get("published_at", ""))
            article["published_date"] = iso
            article["published_label"] = label
            if iso and start <= iso < end:
                filtered.append(article)
        articles = filtered

    # Google News can return a redirect URL. Keep it as the user-facing link;
    # requests follows it when we later attempt to extract article text.
    articles = _decorate_dates(articles)
    articles.sort(key=lambda a: (a.get("relevance", 0), a.get("published_date", "")), reverse=True)
    return articles[:max_results]


def _clean_article_text(value):
    """Normalize extracted article text and reject boilerplate-like fragments."""
    text = BeautifulSoup(str(value or ""), "html.parser").get_text(" ", strip=True)
    text = html.unescape(text)
    return re.sub(r"\\s+", " ", text).strip()


def _extract_jsonld_article(soup):
    """Extract articleBody from common NewsArticle/Article JSON-LD objects."""
    def walk(value):
        if isinstance(value, dict):
            body = value.get("articleBody")
            if isinstance(body, str) and len(body.strip()) > 300:
                return body
            for child in value.values():
                found = walk(child)
                if found:
                    return found
        elif isinstance(value, list):
            for child in value:
                found = walk(child)
                if found:
                    return found
        return ""

    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or script.get_text())
        except (ValueError, TypeError):
            continue
        found = walk(data)
        if found:
            return found
    return ""


def _extract_article_body(html_text, min_chars=350, max_chars=40000):
    """Extract publisher article prose, preferring structured articleBody data."""
    soup = BeautifulSoup(html_text, "html.parser")
    structured = _clean_article_text(_extract_jsonld_article(soup))
    if len(structured) >= min_chars:
        return structured[:max_chars], "json-ld"

    for tag in soup(["script", "style", "nav", "header", "footer", "aside",
                     "form", "noscript", "svg", "button", "iframe"]):
        tag.decompose()

    noise_patterns = re.compile(
        r"(related|recommend|trending|most-read|most-popular|newsletter|"
        r"subscribe|advert|promo|social|share|breadcrumb|comments)", re.I
    )
    for node in soup.find_all(attrs={"class": True}):
        if noise_patterns.search(" ".join(node.get("class", []))):
            node.decompose()
    for node in soup.find_all(attrs={"id": True}):
        if noise_patterns.search(str(node.get("id", ""))):
            node.decompose()

    candidates = []
    for container in soup.find_all(["article", "main"]):
        paragraphs = container.find_all("p")
        candidate = _clean_article_text(" ".join(p.get_text(" ", strip=True) for p in paragraphs))
        if candidate:
            candidates.append(candidate)
    if not candidates:
        candidate = _clean_article_text(" ".join(
            p.get_text(" ", strip=True) for p in soup.find_all("p")
        ))
        if candidate:
            candidates.append(candidate)

    body = max(candidates, key=len) if candidates else ""
    if len(body) >= min_chars:
        return body[:max_chars], "article-paragraphs"
    return "", "insufficient-page-text"


def fetch_full_text(url: str, min_chars: int = 350, max_chars: int = 40000) -> str:
    """Fetch article body; never substitute a headline or short search snippet."""
    if not url or not re.match(r"^https?://", url, re.I):
        return ""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=18, allow_redirects=True)
        resp.raise_for_status()
        body, _method = _extract_article_body(resp.text, min_chars=min_chars, max_chars=max_chars)
        return body
    except (requests.RequestException, ValueError, TypeError):
        return ""


def fetch_articles(articles, max_chars=40000):
    """Return only articles with substantial body text; snippets/headlines are never analysis input."""
    output = []
    candidates = [
        a for a in articles
        if isinstance(a, dict) and a.get("media_type", "news") not in {"community", "video"}
    ]
    fetched = {}
    fetchable = [a for a in candidates if a.get("url")]
    if fetchable:
        with ThreadPoolExecutor(max_workers=min(8, len(fetchable))) as pool:
            future_map = {
                pool.submit(fetch_full_text, a.get("url", ""), max_chars=max_chars): a
                for a in fetchable
            }
            for future in as_completed(future_map):
                article = future_map[future]
                try:
                    fetched[id(article)] = future.result() or ""
                except Exception:
                    fetched[id(article)] = ""

    for article in candidates:
        headline = (article.get("headline") or article.get("title") or "").strip()
        body = fetched.get(id(article), "")
        feed_body = _clean_article_text(article.get("feed_content", ""))
        if len(feed_body) > len(body):
            body = feed_body[:max_chars]
            method = "publisher-feed"
        else:
            method = "web-article"
        if len(body) < 350:
            continue
        output.append({
            "source": article.get("source", "Unknown"), "headline": headline,
            "text": body, "url": article.get("url", ""),
            "published_at": article.get("published_at", ""),
            "published_date": article.get("published_date", ""),
            "published_label": article.get("published_label", "Date unavailable"),
            "used_full_text": True, "extraction_method": method,
            "body_chars": len(body), "media_type": article.get("media_type", "news"),
            "channel": article.get("channel", ""),
        })
    return output


def get_trending_topics(category="general", page_size=12):
    """Get trending stories from Google News; NewsAPI is optional fallback."""
    category = category if category in TOPIC_FEEDS else "general"
    items = _fetch_feed(TOPIC_FEEDS[category], "Google News")[:page_size]

    topics = []
    for article in items:
        if not article.get("headline") or not article.get("url"):
            continue
        topics.append({
            "headline": article["headline"],
            "source": article.get("source") or "Google News",
            "url": article["url"],
            "image_url": "",
            "search_query": article["headline"],
            "published_at": article.get("published_at", ""),
        })
    return topics


def fetch_event_coverage(query: str, max_sources: int = 6, event_date=None):
    """Backward-compatible helper: search, choose distinct outlets, fetch text."""
    candidates = search_news(query, max_results=max(20, max_sources * 4), event_date=event_date)
    selected = []
    seen = set()
    for article in candidates:
        source = article.get("source", "").strip()
        if not source or source.lower() in seen:
            continue
        seen.add(source.lower())
        selected.append(article)
        if len(selected) >= max_sources:
            break
    return fetch_articles(selected)

# Common words are removed when generating related search suggestions from
# the headlines we already collected. This keeps suggestions tied to the
# current story instead of requiring another paid API call.
RELATED_STOPWORDS = {
    "the","a","an","and","or","but","for","with","from","into","after","before",
    "over","under","amid","about","says","say","said","new","latest","news","today",
    "this","that","will","would","could","should","has","have","had","its","their",
    "his","her","they","them","you","your","our","are","was","were","been","being",
    "than","then","what","when","where","which","who","why","how","also","more","most",
    "may","might","can","just","not","all","out","one","two","three","first","second",
}

def related_topics(query: str, articles, limit: int = 8):
    """Suggest related searches from the already-fetched result headlines.

    This is deliberately local: it does not call another API. It finds
    meaningful terms/short phrases that repeatedly occur across the search
    results and turns them into clickable follow-up searches.
    """
    query_words = {w.lower() for w in re.findall(r"[\w'-]+", query) if len(w) > 2}
    counts = Counter()
    for article in articles:
        text = f"{article.get('headline','')} {article.get('snippet','')}".lower()
        words = [w for w in re.findall(r"[a-z][a-z'-]{2,}", text) if w not in RELATED_STOPWORDS]
        # Single terms are useful, but prefer adjacent two-word concepts.
        for w in words:
            if w not in query_words:
                counts[w] += 1
        for a, b in zip(words, words[1:]):
            if a != b and a not in query_words and b not in query_words:
                counts[f"{a} {b}"] += 1.5

    suggestions = []
    used_words = set()
    for phrase, score in counts.most_common(40):
        if len(suggestions) >= limit:
            break
        if isinstance(phrase, str) and " " in phrase:
            key = phrase.lower()
            if any(part in used_words for part in key.split()):
                continue
            suggestions.append(phrase.title())
            used_words.update(key.split())
        else:
            if phrase in used_words:
                continue
            suggestions.append(phrase.title())
            used_words.add(phrase)
    return suggestions
