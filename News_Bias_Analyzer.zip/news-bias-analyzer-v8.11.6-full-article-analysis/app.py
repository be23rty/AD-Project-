"""Flask backend for the multi-source News Bias & Framing Analyzer."""
from flask import Flask, render_template, request, jsonify

from analysis.bias_analyzer import analyze_articles, analyze_target_stance, build_neutral_baseline, summarize_people_perspectives, comparison_options
from analysis.llm_intent import infer_search_intent, infer_article_stance
from fetching.news_fetcher import (
    fetch_articles,
    fetch_event_coverage,
    get_trending_topics,
    search_news,
    related_topics,
    infer_event_date,
    collect_people_perspectives,
)

app = Flask(__name__)


def _attach_comparative_shares(stance, only_if_complete=True):
    """Attach the exact per-article shares used by both the bars and pie chart.

    Shares are a visual normalization of target-specific framing scores, not a
    literal probability that a publisher supports a side. With two targets,
    equal scores are 50/50; stronger score differences move the share away
    from 50 without producing artificial 100/0 results.
    """
    import math
    sides=stance.get("sides", [])
    for row in stance.get("results", []):
        targets=row.get("targets", [])
        by={str(t.get("target")): t for t in targets}
        usable=[]
        for side in sides:
            t=by.get(str(side))
            if not t:
                usable=[]
                break
            # LLM scores are valid even when the target is not explicitly
            # mentioned in the text; the model judged the article against the
            # exact selected sides. Lexical fallback requires evidence for
            # every side before showing a comparative percentage.
            if only_if_complete and not row.get("llm_scored") and int(t.get("mentions",0)) <= 0:
                usable=[]
                break
            usable.append(t)
        if len(usable) < 2:
            row["comparative_shares"] = []
            row["comparative_evidence"] = False
            continue
        # Scores are bounded to [-1, 1]. Temperature .65 gives a useful visual
        # range while preventing normal articles from collapsing to 100/0.
        weights=[math.exp(max(-1.0,min(1.0,float(t.get("score",0))))/.65) for t in usable]
        denom=sum(weights) or 1.0
        shares=[]
        for t,w in zip(usable,weights):
            shares.append({"target":t.get("target"),"value":round(w/denom*100,1)})
        row["comparative_shares"] = shares
        row["comparative_evidence"] = True


def merge_llm_stance(stance, llm_stance):
    """Replace weak lexical scores with LLM target framing and keep all visuals consistent."""
    if not stance:
        return stance
    if llm_stance and llm_stance.get("available"):
        by_index={x.get("index"):x for x in llm_stance.get("results",[])}
        for i,row in enumerate(stance.get("results",[])):
            ai=by_index.get(i)
            if not ai:
                continue
            mapped={x.get("target","").lower():x for x in ai.get("scores",[])}
            matched=0
            for t in row.get("targets",[]):
                x=mapped.get(str(t.get("target","")).lower())
                if x:
                    matched += 1
                    t["score"]=x.get("score",0.0)
                    t["label"]="favorable" if t["score"]>=0.16 else ("unfavorable" if t["score"]<=-0.16 else "neutral / mixed")
                    if x.get("evidence"):
                        t["evidence"]=[{"text":x["evidence"],"signal":"favorable" if t["score"]>0 else ("unfavorable" if t["score"]<0 else "neutral"),"score":t["score"]}]
            if matched >= 2:
                row["llm_scored"] = True
                ranked=sorted(row.get("targets",[]),key=lambda x:float(x.get("score",0)),reverse=True)
                gap=float(ranked[0].get("score",0))-float(ranked[-1].get("score",0))
                row["overall"] = f"leans toward {ranked[0]['target']}" if gap>=0.10 else "mixed / closely balanced"

    # One canonical set of shares is now used by the graph AND the pie chart.
    _attach_comparative_shares(stance, only_if_complete=True)
    sides=stance.get("sides",[])
    totals={s:0.0 for s in sides}; counts={s:0 for s in sides}
    for row in stance.get("results",[]):
        shares=row.get("comparative_shares",[])
        if len(shares)<2:
            continue
        for item in shares:
            target=item.get("target")
            if target in totals:
                totals[target]+=float(item.get("value",0))
                counts[target]+=1
    evidence_rows=sum(1 for r in stance.get("results",[]) if len(r.get("comparative_shares",[]))>=2)
    total=sum(totals.values()) or 1.0
    stance["overall_share"]=[{"target":s,"value":round(totals[s]/total*100,1),"evidence_articles":counts[s]} for s in sides]
    ranked=sorted(stance["overall_share"],key=lambda x:x["value"],reverse=True)
    if len(ranked)>=2 and evidence_rows:
        gap=ranked[0]["value"]-ranked[1]["value"]
        if gap>=8:
            stance["message"]=f"Across {evidence_rows} comparable articles, the media-language signal leans toward {ranked[0]['target']} ({ranked[0]['value']:.1f}% vs {ranked[1]['value']:.1f}%)."
        else:
            stance["message"]=f"Across {evidence_rows} comparable articles, the media-language signal is closely balanced between {ranked[0]['target']} ({ranked[0]['value']:.1f}%) and {ranked[1]['target']} ({ranked[1]['value']:.1f}%)."
    elif len(ranked)>=2:
        stance["message"]="There is not enough comparable evidence to calculate a reliable relative framing share."
    stance["stance_method"]="Target-specific framing is scored from the article text; when Gemini is configured, its article-level judgement is used for the exact selected sides. Percentages are normalized comparative framing shares, not publisher endorsement or public opinion."
    return stance

def _coverage_date_range(articles):
    dates = [a.get("published_date") for a in articles if a.get("published_date")]
    if not dates:
        return ""
    return f"{min(dates)} to {max(dates)}"



@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/trending")
def trending():
    category = request.args.get("category", "general")
    topics = get_trending_topics(category=category)
    if not topics:
        return jsonify({"error": "No trending stories found right now. Try another category."}), 404
    return jsonify({"topics": topics, "category": category})


@app.route("/api/search", methods=["POST"])
def search():
    """Search across Google News RSS, direct RSS feeds and optional NewsAPI."""
    payload = request.get_json(silent=True) or {}
    query = (payload.get("query") or "").strip()
    max_results = min(max(int(payload.get("max_results", 30)), 5), 60)
    sources = payload.get("sources") or []
    if not isinstance(sources, list):
        sources = []
    event_date = (payload.get("event_date") or "").strip() or infer_event_date(query)

    if not query:
        return jsonify({"error": "Provide a search query."}), 400

    # Pass 1: understand the event before retrieval.
    llm_intent = infer_search_intent(query)
    search_query = llm_intent.get("search_query") or query
    event_date = event_date or llm_intent.get("event_date", "")
    articles = search_news(search_query, max_results=max_results, sources=sources, event_date=event_date)

    # Pass 2: let the LLM inspect the actual retrieved coverage. This is what
    # makes broad queries such as "Telangana elections" resolve to the real
    # competing parties instead of treating "Telangana" and "elections" as sides.
    if articles and llm_intent.get("available"):
        llm_intent = infer_search_intent(query, [
            f"{a.get('source','')}: {a.get('headline','')} — {a.get('snippet','')}"
            for a in articles[:40]
        ])
        event_date = event_date or llm_intent.get("event_date", "")
    if not articles:
        return jsonify({"error": "No matching news stories were found."}), 404

    people_raw = collect_people_perspectives(query, articles=articles, event_date=event_date)
    people_perspectives = summarize_people_perspectives(people_raw, query)

    return jsonify({
        "query": query,
        "articles": articles,
        "search_intent": llm_intent,
        "search_note": "Results are filtered to the subject of your query; comparison words such as hit/flop are used for analysis, not as search topics.",
        "sources_found": sorted({a.get("source", "") for a in articles if a.get("source")}),
        "related_topics": related_topics(query, articles),
        "comparison_options": comparison_options(query, articles, llm_intent),
        "event_summary": {
            "type": llm_intent.get("event_type", "unknown"),
            "name": llm_intent.get("event_name", query),
            "competitors": llm_intent.get("competitors", []),
            "dimensions": llm_intent.get("comparison_dimensions", []),
        },
        "source_catalog": [
            "BBC", "The Guardian", "Al Jazeera", "The New York Times",
            "The Hindu", "The Indian Express", "NDTV", "Times of India",
            "Hindustan Times", "India Today", "News18", "Reuters",
            "Associated Press", "NPR", "CNN", "Washington Post", "DW",
            "France 24", "The Wire", "Scroll.in", "Deccan Herald",
            "The Telegraph India", "The Quint", "ThePrint", "Reddit", "YouTube"
        ],
        "selected_sources": sources,
        "historical_mode": bool(event_date),
        "event_date": event_date,
        "coverage_window": "45 days before to 45 days after the incident date" if event_date else "No incident date selected",
        "coverage_date_range": _coverage_date_range(articles),
        "baseline": build_neutral_baseline(query, articles),
        "people_perspectives": people_perspectives,
    })


@app.route("/api/analyze-selected", methods=["POST"])
def analyze_selected():
    """Fetch full text for selected search results and run the existing analyzer."""
    payload = request.get_json(silent=True) or {}
    selected = payload.get("articles", [])
    if not isinstance(selected, list) or len(selected) < 2:
        return jsonify({"error": "Select at least two articles to compare."}), 400

    articles = fetch_articles(selected[:20])
    if len(articles) < 2:
        extracted = len(articles)
        attempted = min(len(selected), 20)
        return jsonify({
            "error": (
                f"Only {extracted} of {attempted} selected articles provided enough "
                "full article text. Headline-only and short-snippet analysis is disabled. "
                "Select more articles or try publishers whose full articles are accessible."
            ),
            "full_text_required": True,
            "articles_with_full_text": extracted,
            "articles_attempted": attempted,
        }), 422

    query = payload.get("query", "")
    compare_targets = payload.get("compare_targets")
    result = analyze_articles(articles)
    llm_intent = infer_search_intent(query, [
        f"{a.get('source','')}: {a.get('headline','')} — {a.get('text','')[:300]}"
        for a in articles[:40]
    ])
    result["search_intent"] = llm_intent
    result["event_summary"] = {"type": llm_intent.get("event_type","unknown"), "name": llm_intent.get("event_name",query), "competitors": llm_intent.get("competitors",[])}
    result["stance"] = analyze_target_stance(articles, query, compare_targets, llm_intent, llm_intent.get("comparison_dimensions", []))
    llm_targets = result["stance"].get("sides", [])
    llm_stance = infer_article_stance(articles, llm_targets)
    result["stance"] = merge_llm_stance(result["stance"], llm_stance)
    result["baseline"] = build_neutral_baseline(query, articles)
    people_raw = collect_people_perspectives(query, articles=articles, event_date=(payload.get("event_date") or "").strip() or infer_event_date(query))
    result["people_perspectives"] = summarize_people_perspectives(people_raw, query)
    url_by_source = {a["source"]: a["url"] for a in articles}
    for item in result.get("results", []):
        item["url"] = url_by_source.get(item.get("source"), "")
    result["selected_count"] = len(articles)
    result["full_text_summary"] = {
        "analysis_basis": "full_article_body_only",
        "articles_analyzed": len(articles),
        "body_characters": sum(int(x.get("body_chars", len(x.get("text", "")))) for x in articles),
        "articles": [
            {"source": x.get("source", "Unknown"), "headline": x.get("headline", ""),
             "body_characters": int(x.get("body_chars", len(x.get("text", "")))),
             "extraction_method": x.get("extraction_method", "web-article")}
            for x in articles
        ],
    }
    return jsonify(result)


@app.route("/api/search-and-analyze", methods=["POST"])
def search_and_analyze():
    """Backward-compatible endpoint used by older versions of the frontend."""
    payload = request.get_json(silent=True) or {}
    query = (payload.get("query") or "").strip()
    max_sources = min(max(int(payload.get("max_sources", 6)), 2), 12)
    event_date = (payload.get("event_date") or "").strip() or infer_event_date(query)
    if not query:
        return jsonify({"error": "Provide a search query."}), 400

    articles = fetch_event_coverage(query, max_sources=max_sources, event_date=event_date)
    if len(articles) < 2:
        return jsonify({"error": "Could not find enough usable outlets for that query."}), 404
    result = analyze_articles(articles)
    llm_intent = infer_search_intent(query, [a.get("headline", "") for a in articles])
    result["search_intent"] = llm_intent
    result["stance"] = analyze_target_stance(articles, query, payload.get("compare_targets"), llm_intent, llm_intent.get("comparison_dimensions", []))
    result["baseline"] = build_neutral_baseline(query, articles)
    url_by_source = {a["source"]: a["url"] for a in articles}
    for item in result.get("results", []):
        item["url"] = url_by_source.get(item.get("source"), "")
    result["query"] = query
    return jsonify(result)


@app.route("/api/analyze", methods=["POST"])
def analyze():
    payload = request.get_json(silent=True) or {}
    articles = payload.get("articles", [])
    if not isinstance(articles, list) or not articles:
        return jsonify({"error": "Provide a non-empty 'articles' list."}), 400

    cleaned = []
    for article in articles:
        source = (article.get("source") or "").strip()
        headline = (article.get("headline") or "").strip()
        text = (article.get("text") or "").strip()
        if source and len(text) >= 350:
            cleaned.append({"source": source, "headline": headline, "text": text})

    if len(cleaned) < 2:
        return jsonify({
            "error": "At least two articles with full body text (350+ characters each) are required. Headlines and short snippets are not analysed.",
            "full_text_required": True,
            "articles_with_full_text": len(cleaned),
        }), 422
    query = payload.get("query", "")
    result = analyze_articles(cleaned)
    llm_intent = infer_search_intent(query, [a.get("headline","") for a in cleaned])
    result["search_intent"] = llm_intent
    result["stance"] = analyze_target_stance(cleaned, query, payload.get("compare_targets"), llm_intent, llm_intent.get("comparison_dimensions", []))
    llm_targets = result["stance"].get("sides", [])
    llm_stance = infer_article_stance(cleaned, llm_targets)
    result["stance"] = merge_llm_stance(result["stance"], llm_stance)
    result["baseline"] = build_neutral_baseline(query or "the submitted event", cleaned)
    people_raw = collect_people_perspectives(query or "the submitted event", articles=[], event_date=payload.get("event_date") or "")
    result["people_perspectives"] = summarize_people_perspectives(people_raw, query)
    return jsonify(result)


@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
