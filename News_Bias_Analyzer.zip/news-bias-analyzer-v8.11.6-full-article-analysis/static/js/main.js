const searchInput = document.getElementById("search-input");
const searchBtn = document.getElementById("search-btn");
const eventDateInput = document.getElementById("event-date");
const historyHint = document.getElementById("history-hint");
const searchError = document.getElementById("search-error");
const baselineCard = document.getElementById("baseline-card");
const baselineSummary = document.getElementById("baseline-summary");
const baselineMeta = document.getElementById("baseline-meta");
const baselineMethod = document.getElementById("baseline-method");
const peopleCard = document.getElementById("people-card");
const peopleSummary = document.getElementById("people-summary");
const peopleStats = document.getElementById("people-stats");
const peopleItems = document.getElementById("people-items");
const peopleMethod = document.getElementById("people-method");
const analysisPeopleSummary = document.getElementById("analysis-people-summary");
const analysisPeopleStats = document.getElementById("analysis-people-stats");
const analysisPeopleItems = document.getElementById("analysis-people-items");
const analysisPeopleMethod = document.getElementById("analysis-people-method");
const analysisBaselineSummary = document.getElementById("analysis-baseline-summary");
const analysisBaselineMeta = document.getElementById("analysis-baseline-meta");
const analysisBaselineMethod = document.getElementById("analysis-baseline-method");
const relatedTopics = document.getElementById("related-topics");
const sourceOptions = document.getElementById("source-options");
const comparePicker = document.getElementById("compare-picker");
const compareOptions = document.getElementById("compare-options");
const compareLeft = document.getElementById("compare-left");
const compareRight = document.getElementById("compare-right");
const compareThird = document.getElementById("compare-third");
const applyCompare = document.getElementById("apply-compare");
const compareCurrent = document.getElementById("compare-current");
const newsResults = document.getElementById("news-results");
const topicCount = document.getElementById("topic-count");
const topicFilter = document.getElementById("topic-filter-input");
const storyTitle = document.getElementById("story-title");
const sourceCount = document.getElementById("source-count");
const analyzeSelectedBtn = document.getElementById("analyze-selected");
const selectionBar = document.getElementById("selection-bar");
const selectionCount = document.getElementById("selection-count");
const selectAllBtn = document.getElementById("select-all");
const clearAllBtn = document.getElementById("clear-all");
const selectionError = document.getElementById("selection-error");
const showManual = document.getElementById("show-manual");
const manual = document.getElementById("manual");
const articleList = document.getElementById("article-list");
const addBtn = document.getElementById("add-article");
const analyzeBtn = document.getElementById("analyze-btn");
const sampleBtn = document.getElementById("load-sample");
const errorMsg = document.getElementById("error-msg");
const results = document.getElementById("results");
const stanceChart = document.getElementById("stance-chart");
const stanceNote = document.getElementById("stance-note");
const signalChart = document.getElementById("signal-chart");
const outletCards = document.getElementById("outlet-cards");
let currentSearchArticles = [];
let selectedSources = [];
let selectedComparison = [];

function escapeHtml(str) { const div = document.createElement("div"); div.textContent = str || ""; return div.innerHTML; }
function addEntry(source="", headline="", text="") { const wrap=document.createElement("div"); wrap.className="article-entry"; wrap.innerHTML=`<div class="article-entry-head"><input type="text" class="source-input" placeholder="Outlet name" value="${escapeHtml(source)}"><button type="button" class="remove-entry">Remove</button></div><input type="text" class="headline-input" placeholder="Headline" value="${escapeHtml(headline)}"><textarea placeholder="Paste article text here">${escapeHtml(text)}</textarea>`; wrap.querySelector(".remove-entry").addEventListener("click",()=>wrap.remove()); articleList.appendChild(wrap); }
function clearEntries(){articleList.innerHTML="";}
addEntry(); addEntry();

showManual.addEventListener("click",()=>{manual.hidden=!manual.hidden; if(!manual.hidden) manual.scrollIntoView({behavior:"smooth",block:"center"});});
addBtn.addEventListener("click",()=>addEntry());
sampleBtn.addEventListener("click",()=>{clearEntries();addEntry("Daily Ledger","City council approves controversial downtown redevelopment plan","The city council voted 5-2 Tuesday to approve a redevelopment plan that critics say will displace dozens of small businesses. Opponents called the decision a betrayal of the neighborhood's character.");addEntry("Metro Herald","Council backs downtown revitalization, promising jobs and growth","In a landmark vote, the city council approved a redevelopment plan expected to bring new jobs and investment downtown. Supporters say the project marks a historic step forward for the local economy.");});

const SOURCE_CATALOG=["BBC","The Guardian","Al Jazeera","The New York Times","The Hindu","The Indian Express","NDTV","Times of India","Hindustan Times","India Today","News18","Reuters","Associated Press","NPR","CNN","Washington Post","DW","France 24","The Wire","Scroll.in","Deccan Herald","The Telegraph India","The Quint","ThePrint","Reddit","YouTube"];
// ============================================================
// SEARCH
// ============================================================
async function readApiResponse(res){
  const text=await res.text();
  let data={};
  try{data=text?JSON.parse(text):{};}catch(e){
    throw new Error(`Server returned an invalid response (${res.status}).`);
  }
  if(!res.ok) throw new Error(data.error||`Request failed (${res.status}).`);
  return data;
}

async function searchNews(queryOverride=""){
  const query=(queryOverride||searchInput?.value||"").trim();
  if(!query){
    if(searchError){searchError.textContent="Enter something to search for.";searchError.hidden=false;}
    searchInput?.focus();
    return;
  }

  if(searchError)searchError.hidden=true;
  if(searchBtn){searchBtn.disabled=true;searchBtn.textContent="Searching…";}

  try{
    const res=await fetch("/api/search",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        query,
        max_results:30,
        sources:selectedSources,
        event_date:eventDateInput?.value||""
      })
    });
    const data=await readApiResponse(res);

    if(searchInput&&!queryOverride)searchInput.value=query;
    if(eventDateInput&&data.event_date&&!eventDateInput.value)eventDateInput.value=data.event_date;
    if(historyHint){
      if(data.historical_mode){
        historyHint.textContent=`Historical coverage: ${data.event_date||"detected event date"} · ${data.coverage_date_range||"original reporting window"}`;
        historyHint.hidden=false;
      }else{
        historyHint.hidden=true;
      }
    }

    renderSourcePickerFromCatalog(data.source_catalog||SOURCE_CATALOG);
    renderComparisonPicker(data.comparison_options||[]);
    renderRelatedTopics(data.related_topics||[],query);
    renderNewsResults(data);

    if(baselineCard){
      baselineCard.hidden=!data.baseline;
      renderBaselineAnalysis(data.baseline);
    }
    renderPeoplePerspectives(data.people_perspectives,"search");

    const workspace=document.getElementById("workspace");
    if(workspace)workspace.scrollIntoView({behavior:"smooth",block:"start"});
  }catch(e){
    if(searchError){
      searchError.textContent=e.message||"Search failed. Please try again.";
      searchError.hidden=false;
    }
  }finally{
    if(searchBtn){searchBtn.disabled=false;searchBtn.textContent="Search";}
  }
}

if(searchBtn)searchBtn.addEventListener("click",()=>searchNews());
if(searchInput)searchInput.addEventListener("keydown",e=>{
  if(e.key==="Enter"){
    e.preventDefault();
    searchNews();
  }
});

function renderSourcePicker(){
  if(!sourceOptions)return;
  sourceOptions.innerHTML="";
  SOURCE_CATALOG.forEach(source=>{
    const label=document.createElement("label");
    label.className="source-option";
    const cb=document.createElement("input"); cb.type="checkbox"; cb.value=source;
    cb.checked=selectedSources.includes(source);
    cb.addEventListener("change",()=>{
      selectedSources=Array.from(sourceOptions.querySelectorAll("input:checked")).map(x=>x.value);
      document.querySelectorAll(".source-option").forEach(el=>el.classList.toggle("active",el.querySelector("input").checked));
    });
    const span=document.createElement("span"); span.textContent=source;
    label.append(cb,span); sourceOptions.appendChild(label);
  });
}
renderSourcePicker();

function renderSourcePickerFromCatalog(catalog){
  if(!Array.isArray(catalog)||!catalog.length)return;
  const valid=new Set(catalog);
  selectedSources=selectedSources.filter(x=>valid.has(x));
  sourceOptions.innerHTML="";
  catalog.forEach(source=>{
    const label=document.createElement("label"); label.className="source-option";
    const cb=document.createElement("input"); cb.type="checkbox"; cb.value=source; cb.checked=selectedSources.includes(source);
    cb.addEventListener("change",()=>{selectedSources=Array.from(sourceOptions.querySelectorAll("input:checked")).map(x=>x.value);document.querySelectorAll(".source-option").forEach(el=>el.classList.toggle("active",el.querySelector("input").checked));});
    const span=document.createElement("span"); span.textContent=source; label.append(cb,span); sourceOptions.appendChild(label);
  });
}

function renderComparisonPicker(options){
  if(!comparePicker||!compareOptions)return;
  compareOptions.innerHTML="";
  const opts=Array.isArray(options)?options:[];
  if(!opts.length){comparePicker.hidden=false;compareOptions.innerHTML='<span class="compare-empty">Choose the sides you want to compare.</span>';renderComparisonCurrent();return;}
  comparePicker.hidden=false;
  // Preselect the first dynamic suggestion so Analyze selected has valid targets.
  // Users can still choose another suggestion or edit the comparison fields.
  if(selectedComparison.length < 2 && Array.isArray(opts[0].targets) && opts[0].targets.length >= 2){
    selectedComparison = opts[0].targets.slice(0,4);
    if(compareLeft) compareLeft.value = selectedComparison[0] || "";
    if(compareRight) compareRight.value = selectedComparison[1] || "";
    if(compareThird) compareThird.value = selectedComparison[2] || "";
  }
  opts.forEach(opt=>{
    const b=document.createElement("button"); b.type="button"; b.className="compare-option"; b.textContent=opt.label;
    b.title=opt.reason||"";
    b.addEventListener("click",()=>{
      selectedComparison=(opt.targets||[]).slice(0,4);
      compareLeft.value=selectedComparison[0]||""; compareRight.value=selectedComparison[1]||"";
      if(compareThird) compareThird.value=selectedComparison[2]||"";
      renderComparisonCurrent(); document.querySelectorAll(".compare-option").forEach(x=>x.classList.remove("active")); b.classList.add("active");
    });
    compareOptions.appendChild(b);
  });
  renderComparisonCurrent();
}
function renderComparisonCurrent(){
  const vals=[compareLeft?.value,compareRight?.value,compareThird?.value].map(x=>(x||"").trim()).filter(Boolean);
  if(compareCurrent)compareCurrent.textContent=vals.length>=2?`Comparing: ${vals.join(" vs ")}`:"Choose at least two sides.";
}
if(applyCompare){applyCompare.addEventListener("click",()=>{
  const vals=[compareLeft?.value,compareRight?.value,compareThird?.value].map(x=>(x||"").trim()).filter(Boolean);
  const unique=vals.filter((v,i)=>vals.findIndex(x=>x.toLowerCase()===v.toLowerCase())===i).slice(0,4);
  if(unique.length>=2){selectedComparison=unique;renderComparisonCurrent();document.querySelectorAll(".compare-option").forEach(x=>x.classList.remove("active"));}
});}

function renderRelatedTopics(topics,query){relatedTopics.innerHTML="";if(!topics.length){relatedTopics.hidden=true;return;}relatedTopics.hidden=false;const label=document.createElement("span");label.className="related-label";label.textContent="Related:";relatedTopics.appendChild(label);topics.slice(0,8).forEach(t=>{const b=document.createElement("button");b.type="button";b.className="topic-chip";b.textContent=t;b.addEventListener("click",()=>searchNews(t));relatedTopics.appendChild(b);});}

function renderNewsResults(data){
  newsResults.innerHTML=""; currentSearchArticles=data.articles||[]; topicCount.textContent=currentSearchArticles.length;
  storyTitle.textContent=data.query || "Search results"; sourceCount.textContent=`${currentSearchArticles.length} stories · ${data.sources_found?.length||0} sources`;
  selectionBar.hidden=!currentSearchArticles.length;
  if(!currentSearchArticles.length){newsResults.innerHTML='<div class="empty-state">No stories matched the subject you searched for. Try the specific title/name or enter an incident date.</div>';return;}
  currentSearchArticles.forEach((a,i)=>{
    const card=document.createElement("div");card.className="topic-card";card.dataset.index=i;
    card.innerHTML=`<input class="topic-check" type="checkbox" data-index="${i}" ${i<8?"checked":""}><div class="topic-card-body"><div class="topic-source"><strong>${escapeHtml(a.source||"Unknown source")}${a.channel?` · ${escapeHtml(a.channel)}`:""}</strong><span>${escapeHtml(a.published_label||a.published_at||"Date unavailable")}</span></div><p class="topic-title">${escapeHtml(a.headline)}</p><p class="topic-snippet">${escapeHtml(a.snippet||"No feed summary available.")}</p>${a.url?`<a class="topic-open" href="${escapeHtml(a.url)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">Open story ↗</a>`:""}</div>`;
    const checkbox=card.querySelector(".topic-check");card.addEventListener("click",e=>{if(e.target.tagName!=="A"&&e.target!==checkbox)checkbox.checked=!checkbox.checked;updateSelection();});checkbox.addEventListener("change",updateSelection);newsResults.appendChild(card);
  });
  updateSelection();
}
function selectedArticles(){return Array.from(document.querySelectorAll(".topic-check:checked")).map(cb=>currentSearchArticles[Number(cb.dataset.index)]).filter(Boolean);}
function updateSelection(){const n=selectedArticles().length;selectionCount.textContent=`${n} selected`;document.querySelectorAll(".topic-card").forEach(c=>c.classList.toggle("selected",c.querySelector(".topic-check").checked));}
selectAllBtn.addEventListener("click",()=>{document.querySelectorAll(".topic-check").forEach(c=>c.checked=true);updateSelection();});
clearAllBtn.addEventListener("click",()=>{document.querySelectorAll(".topic-check").forEach(c=>c.checked=false);updateSelection();});
topicFilter.addEventListener("input",()=>{const q=topicFilter.value.toLowerCase();document.querySelectorAll(".topic-card").forEach(c=>{c.hidden=!c.textContent.toLowerCase().includes(q);});});

analyzeSelectedBtn.addEventListener("click",async()=>{
  selectionError.hidden=true;const selected=selectedArticles();if(selected.length<2){selectionError.textContent="Select at least two stories.";selectionError.hidden=false;return;}
  analyzeSelectedBtn.disabled=true;analyzeSelectedBtn.textContent="Analyzing…";
  try{const res=await fetch("/api/analyze-selected",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({articles:selected,query:searchInput.value.trim(),event_date:eventDateInput?.value||"",compare_targets:selectedComparison})});const data=await readApiResponse(res);renderResults(data);}
  catch(e){selectionError.textContent=e.message||"Could not analyze the selected stories.";selectionError.hidden=false;}
  finally{analyzeSelectedBtn.disabled=false;analyzeSelectedBtn.textContent="Analyze selected";}
});

analyzeBtn.addEventListener("click",async()=>{errorMsg.hidden=true;const entries=Array.from(document.querySelectorAll(".article-entry")).map(el=>({source:el.querySelector(".source-input").value.trim(),headline:el.querySelector(".headline-input").value.trim(),text:el.querySelector("textarea").value.trim()})).filter(e=>e.source&&(e.headline||e.text));if(entries.length<2){errorMsg.textContent="Add at least two outlets.";errorMsg.hidden=false;return;}analyzeBtn.disabled=true;analyzeBtn.textContent="Comparing…";try{const res=await fetch("/api/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({articles:entries})});const data=await readApiResponse(res);renderResults(data);}catch(e){errorMsg.textContent=e.message||"Something went wrong.";errorMsg.hidden=false;}finally{analyzeBtn.disabled=false;analyzeBtn.textContent="Compare coverage";}});

function renderResults(data){
  results.hidden=false;
  const textStatus=document.getElementById("analysis-text-status");
  if(textStatus){
    const full=data.full_text_summary;
    textStatus.textContent=full
      ? `Full article body analysis: ${full.articles_analyzed} articles · ${Number(full.body_characters||0).toLocaleString()} body characters analysed. Headlines and short snippets are excluded from scoring.`
      : "Analysis is based on the article text supplied to the analyzer.";
  }
  renderBaselineAnalysis(data.baseline);renderPeoplePerspectives(data.people_perspectives,"analysis");renderStanceChart(data.stance||{});renderSignalChart(data.results||[]);outletCards.innerHTML="";
  (data.results||[]).forEach(r=>{const card=document.createElement("div");card.className="outlet-card";const stance=(data.stance?.results||[]).find(x=>x.source===r.source);const loaded=(r.loaded_terms||[]).slice(0,6).map(t=>`<span class="chip loaded">${escapeHtml(t.word)} ×${t.count}</span>`).join("");const frames=(r.framing||[]).slice(0,4).map(f=>`<span class="chip">${escapeHtml((f.frame||"").replaceAll("_"," "))} ${f.score}</span>`).join("");const source=r.url?`<a href="${escapeHtml(r.url)}" target="_blank" rel="noopener">${escapeHtml(r.source)} ↗</a>`:escapeHtml(r.source);let stanceHtml="";if(stance?.targets?.length){const ranked=[...stance.targets].filter(x=>x.mentions>0).sort((a,b)=>b.score-a.score);const lead=ranked[0];stanceHtml=`<div class="outlet-stance"><span class="stance-mini-label">${lead&&ranked.length>1&&lead.score-ranked[ranked.length-1].score>=.10?"LEANS TOWARD":"MIXED"}</span><strong>${lead&&ranked.length>1&&lead.score-ranked[ranked.length-1].score>=.10?escapeHtml(lead.target):"Mixed / closely balanced"}</strong></div>`;const ev=(lead?.evidence||[])[0];if(ev)stanceHtml+=`<div class="stance-evidence"><b>Evidence:</b> “${escapeHtml(ev.text)}”</div>`;}card.innerHTML=`<h3>${source}</h3>${stanceHtml}${r.headline?`<p class="outlet-headline">“${escapeHtml(r.headline)}”</p>`:""}<div class="outlet-meta">${frames}${loaded}</div><div class="evidence">${explainSignal(r)}</div>`;outletCards.appendChild(card);});
  results.scrollIntoView({behavior:"smooth",block:"start"});
}
function renderPeoplePerspectives(data, mode="search"){
  const card = mode === "search" ? peopleCard : document.getElementById("analysis-people-card");
  const summary = mode === "search" ? peopleSummary : analysisPeopleSummary;
  const stats = mode === "search" ? peopleStats : analysisPeopleStats;
  const items = mode === "search" ? peopleItems : analysisPeopleItems;
  const method = mode === "search" ? peopleMethod : analysisPeopleMethod;
  if(!card || !summary || !stats || !items || !method) return;
  if(!data || !data.available){ card.hidden = mode === "search"; summary.textContent=data?.summary||"No public community reactions were available."; return; }
  card.hidden=false;
  summary.textContent=data.summary||"";
  const tone=data.tone_counts||{};
  const side=data.side_counts||{};
  const statsHtml=[];
  statsHtml.push(`<span><b>${Number(data.total_reactions||0)}</b> reactions sampled</span>`);
  (data.platforms||[]).forEach(p=>statsHtml.push(`<span>${escapeHtml(p)}</span>`));
  if(tone.positive)statsHtml.push(`<span>Positive ${tone.positive}</span>`);
  if(tone.critical)statsHtml.push(`<span>Critical ${tone.critical}</span>`);
  if(tone["mixed / neutral"])statsHtml.push(`<span>Mixed ${tone["mixed / neutral"]}</span>`);
  stats.innerHTML=statsHtml.join("");
  items.innerHTML=(data.items||[]).map(item=>{
    const date=item.published_at?new Date(item.published_at).toLocaleDateString(undefined,{day:"2-digit",month:"short",year:"numeric"}):"";
    const source=item.url?`<a href="${escapeHtml(item.url)}" target="_blank" rel="noopener">${escapeHtml(item.platform)} ↗</a>`:escapeHtml(item.platform);
    return `<article class="people-item"><div class="people-item-head"><strong>${source}</strong><span>${escapeHtml(item.community||"")} ${date?`· ${date}`:""}</span></div><p>“${escapeHtml(item.text)}”</p><div class="people-item-tags"><span class="chip">${escapeHtml(item.tone)}</span>${item.side&&item.side!=="Mixed / closely balanced"?`<span class="chip">${escapeHtml(item.side)}</span>`:""}${Number(item.score||0)>0?`<span class="chip">${item.score} engagement</span>`:""}</div></article>`;
  }).join("") || `<div class="empty-state">No readable reactions were returned.</div>`;
  method.textContent=data.method||"Public reactions are anecdotal and not representative polling.";
}

function renderBaselineAnalysis(base){
  if(!base)return;
  if(analysisBaselineSummary)analysisBaselineSummary.textContent=base.summary||"No baseline could be constructed.";
  if(analysisBaselineMeta)analysisBaselineMeta.innerHTML=`${base.date_range?`<span>Coverage: ${escapeHtml(base.date_range)}</span>`:""}<span>${escapeHtml((base.sources_used||[]).length+" sources")}</span>`;
  if(analysisBaselineMethod)analysisBaselineMethod.textContent=base.method||"This is a context aid, not ground truth.";
}
function buildStanceChart(container, stance){
  if(!container)return; container.innerHTML="";
  if(!stance?.available || !stance.sides?.length){container.innerHTML='<div class="empty-state">No comparable sides with enough evidence.</div>';return;}
  const sides=stance.sides, wrap=document.createElement("div"); wrap.className="stance-histogram-wrap";
  const legend=document.createElement("div"); legend.className="stance-legend"; legend.innerHTML=sides.map(s=>`<span><i></i>${escapeHtml(s)}</span>`).join(""); wrap.appendChild(legend);
  const chart=document.createElement("div"); chart.className="stance-histogram";
  (stance.results||[]).forEach(r=>{
    const group=document.createElement("div"); group.className="stance-source-group";
    const targets=r.targets||[];
    const pctMap=new Map((r.comparative_shares||[]).map(x=>[x.target,Number(x.value)]));
    const bars=document.createElement("div"); bars.className="stance-bars"; bars.style.setProperty("--side-count",Math.max(sides.length,2));
    sides.forEach(side=>{const pct=pctMap.has(side)?pctMap.get(side):null; const bar=document.createElement("div");bar.className="stance-column";bar.innerHTML=`<div class="stance-percent">${pct===null?"—":pct.toFixed(1)+"%"}</div><div class="stance-column-track"><div class="stance-column-fill ${pct===null?"unknown":pct>=60?"favorable":pct<=40?"unfavorable":"neutral"}" style="height:${pct===null?0:Math.max(3,pct)}%"></div></div><div class="stance-side-label">${escapeHtml(side)}</div><div class="stance-evidence-label">${pct===null?"Insufficient comparison":pct>=60?"leans here":pct<=40?"less relative share":"closely balanced"}</div>`;bars.appendChild(bar);});
    const source=document.createElement("div");source.className="stance-source-label";source.innerHTML=`<strong>${escapeHtml(r.source||"Unknown source")}</strong><span>${escapeHtml(r.overall||"")}</span>`;
    group.appendChild(source);group.appendChild(bars);chart.appendChild(group);
  });
  wrap.appendChild(chart);container.appendChild(wrap);
}
function renderOverallPie(share){
  const box=document.getElementById("overall-support"), pie=document.getElementById("overall-pie"); if(!box||!pie)return;
  if(!Array.isArray(share)||share.length<2){box.hidden=true;return;} box.hidden=false;
  let start=0; const stops=[]; const total=share.reduce((n,x)=>n+Number(x.value||0),0)||100;
  share.forEach((x,i)=>{const end=start+Number(x.value||0)/total*360;stops.push(`var(--pie-${i%6}) ${start}deg ${end}deg`);start=end;});
  pie.innerHTML=`<div class="pie-chart" style="background:conic-gradient(${stops.join(",")})"></div><div class="pie-legend">${share.map((x,i)=>`<div><i style="background:var(--pie-${i%6})"></i><span><b>${escapeHtml(x.target)}</b> ${Number(x.value||0).toFixed(1)}%</span><small>${Number(x.evidence_articles||0)} articles with comparative evidence</small></div>`).join("")}</div>`;
}
function renderStanceChart(stance){
  const main=document.getElementById("stance-chart"), dims=document.getElementById("stance-dimensions");
  if(main)main.innerHTML=""; if(dims)dims.innerHTML="";
  if(!stance?.available||!stance.sides?.length){if(main)main.innerHTML='<div class="empty-state">Choose competitors in the Compare control above.</div>';if(dims)dims.innerHTML="";renderOverallPie([]);return;}
  buildStanceChart(main,stance);
  (stance.dimensions||[]).forEach(d=>{const card=document.createElement("article");card.className="dimension-chart-card";card.innerHTML=`<div class="dimension-head"><div><strong>${escapeHtml(d.name||"Framing dimension")}</strong><span>${escapeHtml(d.reason||"")}</span></div></div><div class="dimension-chart"></div>`;dims.appendChild(card);buildStanceChart(card.querySelector(".dimension-chart"),d);});
  renderOverallPie(stance.overall_share||[]);
  stanceNote.textContent=stance.message||"Relative language signal between the selected sides.";
}
function renderSignalChart(rows){signalChart.innerHTML="";if(!rows.length)return;const metrics=[{key:"subjectivity",label:"Subjective / loaded",max:1,format:v=>Math.round(v*100)+"%"},{key:"loaded",label:"Loaded terms",max:Math.max(1,...rows.map(r=>(r.loaded_terms||[]).reduce((n,x)=>n+x.count,0))),format:v=>v},{key:"headline_body_gap",label:"Headline ↔ body gap",max:1,format:v=>Math.round(v*100)+"%"}];const avg=k=>rows.reduce((n,r)=>n+(k==="loaded"?(r.loaded_terms||[]).reduce((s,x)=>s+x.count,0):Number(r[k]||0)),0)/rows.length;metrics.forEach(m=>{const v=avg(m.key),pct=Math.min(100,(v/m.max)*100);const row=document.createElement("div");row.className="signal-row";row.innerHTML=`<div class="signal-head"><b>${m.label}</b><span>${m.format(v)}</span></div><div class="signal-track"><div class="signal-fill" style="width:${pct}%"></div></div>`;signalChart.appendChild(row);});}
function explainSignal(r){const parts=[];if((r.loaded_terms||[]).length)parts.push(`${r.loaded_terms.length} loaded-language types detected`);if((r.framing||[]).length)parts.push(`main frame: ${(r.framing[0].frame||"").replaceAll("_"," ")}`);if(r.headline_body_gap>0.15)parts.push(`headline/body tone differs noticeably (${Math.round(r.headline_body_gap*100)}%)`);if(!parts.length)parts.push("No strong lexical signal was detected by the current rule set.");return parts.join(" · ");}
function colorForSentiment(score){if(score>0.15)return"#3e8a68";if(score<-0.15)return"#c65353";return"#c78b35";}
