"""Dynamic event/comparison intent using Gemini structured output."""
import json
import os
import re
import requests

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


def _normalise(value):
    return re.sub(r"\s+", " ", str(value or "")).strip(" \t\r\n.,;:!?-")


def _unique(values, limit=8):
    out = []
    for value in values or []:
        value = _normalise(value)
        if value and value.lower() not in {x.lower() for x in out}:
            out.append(value)
    return out[:limit]


def _call_gemini(prompt, schema, api_key):
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": schema,
            "temperature": 0.1,
        },
    }
    response = requests.post(
        GEMINI_URL.format(model=GEMINI_MODEL),
        params={"key": api_key}, json=body, timeout=25,
    )
    response.raise_for_status()
    payload = response.json()
    text = payload["candidates"][0]["content"]["parts"][0]["text"]
    return json.loads(text)


def infer_search_intent(query, headlines=None):
    """Infer the event, competing sides and independent framing dimensions.

    This deliberately contains no event/topic lookup table. The model reasons
    from the user's query plus retrieved article context.
    """
    query = (query or "").strip()
    headlines = [str(x).strip() for x in (headlines or []) if str(x).strip()][:40]
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key or not query:
        return {
            "available": False, "provider": "none", "search_subject": query,
            "search_query": query, "event_type": "unknown", "event_name": query,
            "competitors": [], "comparison_candidates": [], "comparison_dimensions": [],
            "recommended_comparison": [], "comparison_type": "unknown", "confidence": 0.0,
        }

    prompt = f"""You are the dynamic event-intent engine for a news framing analyzer.

USER QUERY:
{query}

ARTICLE HEADLINES (may be empty; use them as evidence, not as a lookup table):
{json.dumps(headlines, ensure_ascii=False)}

Infer what should be compared. Do not decide who is morally or factually correct.

Rules:
1. Identify the concrete event/topic and, when possible, the event type: war/conflict,
   election, sports game/match, movie/game review, political event, disaster, policy,
   or other recent event.
2. If the query is broad (for example "Telangana elections", "World War 1", or a
   war name), identify the actual competing sides/teams/parties/factions involved.
3. Do NOT treat a place, religion, country or person mentioned only as context as a
   competitor. Competitors must actually represent opposing/relevant sides in the event.
4. Generate useful comparison candidates. Prefer 2 or 3 sides when the event genuinely
   has 3 meaningful competitors. Include the likely main comparison first.
5. Generate independent framing dimensions ONLY when they are materially present or
   logically central to the event. Examples: military/security, territorial/geographic,
   political/governance, economic, humanitarian/civilian impact, religious/identity,
   legal/international-law, or performance/gameplay. Do not force every dimension.
6. If the event is historical and a reliable key date is inferable, return event_date as YYYY-MM-DD. For elections, use the main polling/result date; for a specific attack/event, use the incident date. Leave it empty when the date is uncertain or the event is ongoing.
7. For a religious/identity dimension, never reduce a population to one religion.
   Use careful labels such as "Israeli/Jewish identity framing" and
   "Palestinian/Arab/Muslim identity framing" only when supported by the coverage.
8. For each dimension, provide 2-4 comparison targets that make sense for that dimension.
   A dimension can reuse the event competitors, but it can also use claims/frames rather
   than people if that is what is being compared.
9. "Overall support" in this application means aggregate media-language support/lean
   across the selected articles, NOT public opinion and NOT proof that an outlet endorses
   a side. Never invent polling numbers.
10. search_query should preserve the event subject and useful disambiguation, but should
   not become a query for the comparison labels themselves.

Return JSON only.
"""

    schema = {
        "type": "OBJECT",
        "properties": {
            "search_subject": {"type": "STRING"},
            "search_query": {"type": "STRING"},
            "event_type": {"type": "STRING"},
            "event_name": {"type": "STRING"},
            "event_date": {"type": "STRING"},
            "competitors": {"type": "ARRAY", "items": {"type": "STRING"}},
            "comparison_candidates": {"type": "ARRAY", "items": {
                "type": "OBJECT", "properties": {
                    "targets": {"type": "ARRAY", "items": {"type": "STRING"}},
                    "label": {"type": "STRING"}, "reason": {"type": "STRING"}
                }, "required": ["targets", "label", "reason"]
            }},
            "comparison_dimensions": {"type": "ARRAY", "items": {
                "type": "OBJECT", "properties": {
                    "name": {"type": "STRING"},
                    "targets": {"type": "ARRAY", "items": {"type": "STRING"}},
                    "label": {"type": "STRING"},
                    "reason": {"type": "STRING"}
                }, "required": ["name", "targets", "label", "reason"]
            }},
            "recommended_comparison": {"type": "ARRAY", "items": {"type": "STRING"}},
            "comparison_type": {"type": "STRING"},
            "confidence": {"type": "NUMBER"}
        },
        "required": ["search_subject", "search_query", "event_type", "event_name", "event_date",
                      "competitors", "comparison_candidates", "comparison_dimensions",
                      "recommended_comparison", "comparison_type", "confidence"]
    }

    try:
        data = _call_gemini(prompt, schema, api_key)
        candidates = []
        for item in data.get("comparison_candidates", []):
            targets = _unique(item.get("targets", []), 4)
            if len(targets) >= 2:
                candidates.append({
                    "targets": targets,
                    "label": _normalise(item.get("label") or " vs ".join(targets)),
                    "reason": _normalise(item.get("reason") or "Dynamic event comparison"),
                })
        dimensions = []
        for item in data.get("comparison_dimensions", []):
            targets = _unique(item.get("targets", []), 4)
            if len(targets) >= 2:
                dimensions.append({
                    "name": _normalise(item.get("name") or "Framing dimension"),
                    "label": _normalise(item.get("label") or " vs ".join(targets)),
                    "targets": targets,
                    "reason": _normalise(item.get("reason") or "Detected as relevant to the event"),
                })
        competitors = _unique(data.get("competitors", []), 8)
        recommended = _unique(data.get("recommended_comparison", []), 4)
        return {
            "available": True, "provider": "Gemini", "model": GEMINI_MODEL,
            "search_subject": _normalise(data.get("search_subject") or query),
            "search_query": _normalise(data.get("search_query") or query),
            "event_type": _normalise(data.get("event_type") or "unknown").lower(),
            "event_name": _normalise(data.get("event_name") or query),
            "event_date": _normalise(data.get("event_date") or ""),
            "competitors": competitors,
            "comparison_candidates": candidates[:8],
            "comparison_dimensions": dimensions[:8],
            "recommended_comparison": recommended,
            "comparison_type": _normalise(data.get("comparison_type") or "unknown").lower(),
            "confidence": max(0.0, min(1.0, float(data.get("confidence", 0.0)))),
        }
    except Exception as exc:
        return {"available": False, "provider": "Gemini", "error": str(exc),
                "search_subject": query, "search_query": query,
                "event_type": "unknown", "event_name": query, "event_date": "", "competitors": [],
                "comparison_candidates": [], "comparison_dimensions": [],
                "recommended_comparison": [], "comparison_type": "unknown", "confidence": 0.0}


def infer_article_stance(articles, targets):
    """Use Gemini to judge target-specific framing for selected articles.

    This is deliberately separate from search intent: the model sees the actual
    article text and the exact sides chosen by the user, so generic sentiment
    cannot accidentally become a side label.
    """
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    targets = _unique(targets, 4)
    if not api_key or len(targets) < 2 or not articles:
        return {"available": False, "results": []}

    compact=[]
    for i,a in enumerate(articles[:20]):
        # Send extracted article body only; never score a headline or RSS snippet.
        text = (a.get("text") or "").strip()
        if len(text) < 350:
            continue
        compact.append({
            "index": i,
            "source": a.get("source", ""),
            "body_chars": len(text),
            "article_body": text[:40000],
        })
    if not compact:
        return {"available": False, "results": [], "error": "No full article bodies were available for Gemini analysis."}

    prompt=f"""You are a careful news-framing analyst.

The user selected these competing targets:
{json.dumps(targets, ensure_ascii=False)}

Analyze each article body below ONLY against those targets. Do not invent a side.
The article_body field contains the extracted article body (up to 40,000 characters).
Do not use headlines, search snippets, publisher names, or outside knowledge as evidence.
Base the score on evidence across the whole supplied body, not only the opening paragraph.
A score is the article body's target-specific framing signal, not public opinion, factual
truth, or proof that the publisher endorses a side.

Scoring:
+1.0 = strongly favorable framing toward that target
+0.5 = noticeably favorable
 0.0 = neutral, balanced, purely factual, or insufficient evidence
-0.5 = noticeably unfavorable framing
-1.0 = strongly unfavorable framing

Important:
- 'X attacked Y' does not automatically mean the article supports Y; judge the
  article's actual evaluative/contextual framing.
- Do not treat merely mentioning a target as support.
- Compare the targets independently.
- If the article gives materially more favorable language, legitimacy, justification,
  praise, blame allocation, or sympathetic context to one target, reflect that.
- Give a short evidence sentence only when there is actual framing evidence.

ARTICLES:
{json.dumps(compact, ensure_ascii=False)}

Return JSON only.
"""

    score_schema={
        "type":"OBJECT",
        "properties":{
            "index":{"type":"INTEGER"},
            "scores":{"type":"ARRAY","items":{"type":"OBJECT","properties":{
                "target":{"type":"STRING"},
                "score":{"type":"NUMBER"},
                "evidence":{"type":"STRING"}
            },"required":["target","score","evidence"]}},
            "confidence":{"type":"NUMBER"}
        },
        "required":["index","scores","confidence"]
    }
    schema={"type":"OBJECT","properties":{"results":{"type":"ARRAY","items":score_schema}},"required":["results"]}
    try:
        data=_call_gemini(prompt, schema, api_key)
        out=[]
        for row in data.get("results",[]):
            idx=int(row.get("index",-1))
            if idx<0 or idx>=len(compact):
                continue
            scores=[]
            for x in row.get("scores",[]):
                target=_normalise(x.get("target"))
                if target.lower() not in {t.lower() for t in targets}:
                    continue
                try: score=max(-1.0,min(1.0,float(x.get("score",0))))
                except Exception: score=0.0
                scores.append({"target":target,"score":round(score,3),"evidence":_normalise(x.get("evidence"))[:500]})
            if len(scores)>=2:
                out.append({"index":idx,"scores":scores,"confidence":max(0.0,min(1.0,float(row.get("confidence",0))))})
        return {"available":True,"provider":"Gemini","model":GEMINI_MODEL,"results":out}
    except Exception as exc:
        return {"available":False,"provider":"Gemini","error":str(exc),"results":[]}
