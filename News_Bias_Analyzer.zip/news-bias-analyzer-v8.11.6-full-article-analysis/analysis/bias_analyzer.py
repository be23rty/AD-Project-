"""
Lightweight, dependency-free bias & framing analyzer.

This module is intentionally simple: a lexicon-based sentiment score,
a loaded-language detector, and a naive framing-category tagger. It's
built so the web app has real, working output from the first commit.

WHERE TO UPGRADE THIS LATER:
- Swap `sentiment_score()` for a fine-tuned transformer
  (e.g. cardiffnlp/twitter-roberta-base-sentiment via HuggingFace).
- Swap `detect_framing()` for a classifier trained on a labeled
  framing dataset (e.g. the Media Frames Corpus) instead of keyword
  matching.
- Add named-entity + quote attribution (spaCy) to see whose voices
  are quoted and how.
"""
import re
from collections import Counter

# --- small self-contained lexicons -----------------------------------------

POSITIVE_WORDS = {
    "win", "wins", "won", "success", "successful", "praise", "praised",
    "hero", "breakthrough", "progress", "boost", "support", "supports",
    "supported", "improve", "improved", "gain", "gains", "landmark",
    "historic", "triumph", "relief", "welcome", "welcomed", "strong",
    "secure", "secured", "agreement", "peace", "hope", "hopeful",
}

NEGATIVE_WORDS = {
    "crisis", "chaos", "fail", "failed", "failure", "attack", "attacked",
    "slam", "slammed", "blast", "blasted", "blame", "blamed", "scandal",
    "outrage", "controversial", "controversy", "collapse", "threat",
    "threatens", "fear", "feared", "danger", "dangerous", "corrupt",
    "corruption", "chaos", "clash", "clashed", "condemn", "condemned",
    "crackdown", "backlash", "turmoil", "unrest", "violence", "violent",
}

# words that signal emotionally loaded / subjective framing rather than
# neutral reporting, regardless of positive/negative valence
LOADED_WORDS = {
    "slam", "slammed", "blast", "blasted", "shocking", "stunning",
    "explosive", "bombshell", "radical", "extremist", "regime",
    "so-called", "claims", "alleges", "allegedly", "propaganda",
    "outrageous", "unprecedented", "disaster", "catastrophe", "heroic",
    "villain", "slur", "smear",
}

# very small keyword sets standing in for framing "angles" — a real
# system would use a trained classifier instead of keyword matching
FRAME_KEYWORDS = {
    "economic": {"economy", "jobs", "market", "trade", "tax", "prices",
                 "inflation", "wages", "budget", "cost"},
    "security": {"security", "military", "threat", "war", "police",
                 "safety", "attack", "terror", "defense"},
    "moral": {"moral", "ethics", "values", "rights", "justice",
              "fairness", "wrong", "right", "shame"},
    "political": {"election", "vote", "party", "policy", "government",
                  "senator", "president", "law", "bill", "congress"},
    "human_interest": {"family", "victim", "survivor", "community",
                        "children", "story", "life", "personal"},
}

WORD_RE = re.compile(r"[a-zA-Z']+")


def _tokenize(text: str):
    return [w.lower() for w in WORD_RE.findall(text or "")]


def sentiment_score(text: str) -> float:
    """Return a score from -1 (very negative) to +1 (very positive)."""
    tokens = _tokenize(text)
    if not tokens:
        return 0.0
    pos = sum(1 for t in tokens if t in POSITIVE_WORDS)
    neg = sum(1 for t in tokens if t in NEGATIVE_WORDS)
    total = pos + neg
    if total == 0:
        return 0.0
    return round((pos - neg) / total, 3)


def loaded_language(text: str):
    """Return the list of emotionally loaded terms found in the text."""
    tokens = _tokenize(text)
    counts = Counter(t for t in tokens if t in LOADED_WORDS)
    return [{"word": w, "count": c} for w, c in counts.most_common()]


def detect_framing(text: str):
    """Return a ranked list of {frame, score} based on keyword overlap."""
    tokens = set(_tokenize(text))
    scores = []
    for frame, keywords in FRAME_KEYWORDS.items():
        overlap = len(tokens & keywords)
        if overlap:
            scores.append({"frame": frame, "score": overlap})
    scores.sort(key=lambda s: s["score"], reverse=True)
    return scores


def subjectivity_score(text: str) -> float:
    """0 (purely factual-sounding) to 1 (highly subjective/loaded)."""
    tokens = _tokenize(text)
    if not tokens:
        return 0.0
    loaded = sum(1 for t in tokens if t in LOADED_WORDS)
    return round(min(loaded / max(len(tokens) * 0.05, 1), 1.0), 3)


def analyze_articles(articles):
    """
    articles: list of {source, headline, text}
    returns: {
      "results": [ per-article scores ... ],
      "summary": { spread stats across outlets }
    }
    """
    results = []
    for a in articles:
        # All article-level metrics use the extracted body only.
        # Headline sentiment is retained as a separate diagnostic, never mixed
        # into the body score or target-specific bias calculation.
        body = (a.get("text") or "").strip()
        if len(body) < 350:
            continue
        combined = body
        sentiment = sentiment_score(combined)
        headline_sentiment = sentiment_score(a.get("headline", ""))
        results.append({
            "source": a["source"],
            "headline": a["headline"],
            "sentiment": sentiment,
            "headline_sentiment": headline_sentiment,
            "headline_body_gap": round(abs(headline_sentiment - sentiment), 3),
            "body_characters": len(body),
            "analysis_basis": "full_article_body",
            "subjectivity": subjectivity_score(combined),
            "loaded_terms": loaded_language(combined),
            "framing": detect_framing(combined),
        })

    if not results:
        return {"results": [], "summary": {"outlet_count": 0, "message": "No articles with sufficient full-text content were available."}}

    sentiments = [r["sentiment"] for r in results]
    summary = {
        "outlet_count": len(results),
        "sentiment_min": min(sentiments),
        "sentiment_max": max(sentiments),
        "sentiment_spread": round(max(sentiments) - min(sentiments), 3),
        "most_positive_source": max(results, key=lambda r: r["sentiment"])["source"],
        "most_negative_source": min(results, key=lambda r: r["sentiment"])["source"],
        "most_subjective_source": max(results, key=lambda r: r["subjectivity"])["source"],
    }

    return {"results": results, "summary": summary}


# --- neutral context baseline ----------------------------------------------
# This is intentionally extractive rather than generative. It selects factual-
# sounding sentences that recur across sources, removes strongly loaded
# wording from consideration, and reports the coverage date range. This gives
# users context without pretending the baseline is an objective ground truth.
NEUTRAL_SKIP = {
    "shocking", "outrage", "disgraceful", "evil", "heroic", "brutal",
    "horrific", "outrageous", "cowardly", "historic", "sensational",
}

def _baseline_tokens(text):
    return set(t for t in _tokenize(text) if len(t) > 3 and t not in RELATED_BASELINE_STOPWORDS)

RELATED_BASELINE_STOPWORDS = {
    "this", "that", "these", "those", "with", "from", "into", "after",
    "before", "about", "said", "says", "they", "their", "there", "have",
    "been", "were", "will", "would", "could", "should", "more", "than",
    "what", "when", "where", "which", "while", "also", "just", "over",
}

def _neutral_sentence_score(sentence, article_count):
    low = sentence.lower()
    toks = _baseline_tokens(sentence)
    if not (5 <= len(toks) <= 55):
        return -10
    if sum(1 for w in NEUTRAL_SKIP if re.search(r"\b" + re.escape(w) + r"\b", low)) >= 2:
        return -10
    score = 0.0
    # Factual anchors: dates, numbers, locations/entities and event verbs.
    score += min(2.0, len(re.findall(r"\b\d{1,4}\b", sentence)) * 0.5)
    score += min(1.5, len(re.findall(r"\b[A-Z][a-z]{2,}\b", sentence)) * 0.12)
    if re.search(r"\b(on|in|during|following|after|before)\b", low):
        score += 0.35
    if re.search(r"\b(killed|died|announced|approved|elected|signed|launched|met|voted|reported|arrested|filed|began|ended|held)\b", low):
        score += 0.65
    if re.search(r"\b(according to|officials|government|police|court|statement)\b", low):
        score += 0.2
    # Penalize direct opinion / rhetoric.
    if re.search(r"\b(i think|in my view|should|must|obviously|clearly|deserves)\b", low):
        score -= 1.0
    return score

def build_neutral_baseline(query, articles):
    """Create a cautious, extractive context summary from selected coverage."""
    candidates = []
    for idx, article in enumerate(articles):
        source = article.get("source", "Unknown")
        text = (article.get("text") or "").strip()
        seen = set()
        for sentence in _sentence_split(text):
            sentence = re.sub(r"\s+", " ", sentence).strip()
            key = re.sub(r"[^a-z0-9]+", " ", sentence.lower()).strip()
            if key in seen or len(sentence) < 50:
                continue
            seen.add(key)
            score = _neutral_sentence_score(sentence, len(articles))
            if score <= 0:
                continue
            tokens = _baseline_tokens(sentence)
            candidates.append({"text": sentence[:420], "score": score, "source": source, "tokens": tokens})

    # Prefer sentences whose vocabulary overlaps with several different
    # outlets. This is the closest thing here to a cross-source baseline.
    for c in candidates:
        support = 0
        for other in candidates:
            if other is c or other["source"] == c["source"]:
                continue
            overlap = len(c["tokens"] & other["tokens"])
            if overlap >= 4:
                support += 1
        c["score"] += min(2.5, support * 0.45)

    candidates.sort(key=lambda x: x["score"], reverse=True)
    chosen = []
    chosen_tokens = set()
    chosen_keys = set()
    for c in candidates:
        ckey = re.sub(r"[^a-z0-9]+", " ", c["text"].lower()).strip()
        if ckey in chosen_keys:
            continue
        if any(len(c["tokens"] & _baseline_tokens(x["text"])) >= 7 for x in chosen):
            continue
        chosen.append(c)
        chosen_keys.add(ckey)
        chosen_tokens |= c["tokens"]
        if len(chosen) >= 3:
            break

    dates = []
    for a in articles:
        d = a.get("published_date", "")
        if d:
            dates.append(d)
    date_range = ""
    if dates:
        date_range = f"Coverage dates: {min(dates)} to {max(dates)}."

    if chosen:
        summary = " ".join(c["text"] for c in chosen)
    else:
        summary = (
            f"This search concerns {query}. The selected coverage did not provide enough "
            "cross-source factual sentences to construct a reliable extractive baseline."
        )

    return {
        "title": "Neutral context baseline",
        "summary": summary,
        "date_range": date_range,
        "method": "Extractive cross-source baseline: selects factual-sounding sentences with shared vocabulary across outlets. It is context, not ground truth. Historical results are constrained to the selected incident window so later anniversary coverage is not treated as the original event.",
        "sources_used": sorted({a.get("source", "Unknown") for a in articles if a.get("source")}),
    }

# --- target / side-specific stance -----------------------------------------
# Lightweight target-specific stance.  This deliberately does NOT use the
# overall sentiment of the article.  It looks for relationships between a
# named side and nearby actions/descriptions, then compares the sides.
SIDE_ALIASES = {
    "Russia": ["russia", "russian", "moscow", "putin"],
    "Ukraine": ["ukraine", "ukrainian", "kyiv", "zelensky", "zelenskyy"],
    "Israel": ["israel", "israeli", "netanyahu"],
    "Palestine": ["palestine", "palestinian", "gaza", "west bank"],
    "Hamas": ["hamas"],
    "India": ["india", "indian", "new delhi", "modi"],
    "Pakistan": ["pakistan", "pakistani", "islamabad"],
    "China": ["china", "chinese", "beijing", "xi jinping"],
    "United States": ["united states", "u.s.", "america", "american", "washington", "trump", "biden"],
    "Iran": ["iran", "iranian", "tehran"],
    "BJP": ["bjp", "bharatiya janata party"],
    "Congress": ["congress", "indian national congress", "inc"],
    "Democrats": ["democrat", "democrats", "democratic party"],
    "Republicans": ["republican", "republicans", "gop", "republican party"],
    "Labour": ["labour", "labour party"],
    "Conservatives": ["conservative", "conservatives", "conservative party", "tories"],
    "Hinduism": ["hindu", "hinduism", "hindus"],
    "Islam": ["islam", "muslim", "muslims"],
    "Christianity": ["christian", "christianity", "christians"],
    "Judaism": ["jewish", "judaism", "jews"],
}

STANCE_NEGATIVE_ACTIONS = {
    "attack", "attacked", "attacks", "invade", "invaded", "invades", "bomb", "bombed",
    "bombing", "kill", "killed", "killing", "threaten", "threatened", "threatens",
    "condemn", "condemned", "condemnation", "blame", "blamed", "accuse", "accused",
    "slam", "slammed", "reject", "rejected", "criticize", "criticised", "criticized",
    "crackdown", "oppress", "oppressed", "arrest", "arrested", "sanction", "sanctioned",
    "destroy", "destroyed", "damage", "damaged", "violate", "violated", "threat",
    "threatened", "fail", "failed", "failure", "corrupt", "corruption", "lie", "lied",
    "steal", "stole", "abuse", "abused", "expel", "expelled", "flee", "fled",
}
STANCE_POSITIVE_ACTIONS = {
    "support", "supported", "supports", "help", "helped", "helps", "praise", "praised",
    "praises", "approve", "approved", "approves", "defend", "defended", "defends",
    "protect", "protected", "protects", "welcome", "welcomed", "welcomes", "agree", "agreed",
    "restore", "restored", "succeed", "succeeded", "success", "benefit", "benefited",
    "improve", "improved", "advance", "advanced", "peace", "cooperate", "cooperated",
}


def _canonical_side_for_term(term):
    t = term.lower().strip()
    for canonical, aliases in SIDE_ALIASES.items():
        if t in aliases:
            return canonical
    return term.strip()


COMPARISON_PATTERNS = [
    (r"\b(?:hit|flop|hit or flop|flop or hit)\b", [
        ("Hit", ["hit", "hit movie", "blockbuster", "success", "successful", "super hit", "superhit", "average hit", "semi hit", "profitable", "profit", "strong opening", "strong run", "box office success"]),
        ("Flop", ["flop", "flopped", "failure", "failed", "disaster", "box office failure", "loss", "losses", "underperformed", "underperforming", "poor run"]),
    ]),
    (r"\b(?:success|successful|failure|fail|failed)\b", [
        ("Success", ["success", "successful", "succeed", "succeeded", "hit", "profitable", "profit", "strong performance"]),
        ("Failure", ["failure", "fail", "failed", "flop", "flopped", "loss", "losses", "underperformed", "poor performance"]),
    ]),
    (r"\b(?:good|bad)\b", [
        ("Good", ["good", "great", "excellent", "positive", "strong", "well received", "praised", "impressive"]),
        ("Bad", ["bad", "poor", "weak", "negative", "terrible", "disappointing", "criticized", "underwhelming"]),
    ]),
    (r"\b(?:pro|con|pros and cons)\b", [
        ("Pros", ["pro", "pros", "advantage", "benefit", "benefits", "strength", "strengths"]),
        ("Cons", ["con", "cons", "disadvantage", "drawback", "drawbacks", "weakness", "weaknesses"]),
    ]),
    (r"\b(?:support|oppose|support or oppose)\b", [
        ("Support", ["support", "supported", "supports", "back", "backed", "approve", "approved", "favour", "favor"]),
        ("Oppose", ["oppose", "opposed", "opposes", "reject", "rejected", "criticize", "criticised", "criticized", "against"]),
    ]),
]

def comparison_options(query="", articles=None, llm_intent=None):
    """Return dynamic event comparisons suggested by the LLM, then explicit query syntax."""
    options = []
    if llm_intent:
        for candidate in llm_intent.get("comparison_candidates", []):
            targets = [str(x).strip() for x in candidate.get("targets", []) if str(x).strip()]
            if len(targets) >= 2:
                options.append({
                    "label": candidate.get("label") or " vs ".join(targets),
                    "targets": targets[:4],
                    "reason": candidate.get("reason", "Dynamic event comparison"),
                    "source": "llm",
                })
    requested = detect_requested_comparison(query)
    if requested and not any([o.get("targets", [])[:2] == requested.get("targets", [])[:2] for o in options]):
        options.insert(0, {
            "label": " vs ".join(requested["targets"][:4]),
            "targets": requested["targets"][:4],
            "reason": requested.get("reason", "explicit query"),
            "source": "query",
        })
    return options[:8]

def detect_requested_comparison(query=""):
    """Infer what the user actually wants compared, before looking at article entities."""
    q = re.sub(r"\s+", " ", (query or "").lower()).strip()
    # Explicit X vs Y is the strongest signal.
    m = re.search(r"\b(.{1,60}?)\s+(?:vs\.?|versus|against)\s+(.{1,60}?)(?:\?|$)", q, re.I)
    if m:
        left = re.sub(r"\s+", " ", m.group(1)).strip(" .,!?-")
        right = re.sub(r"\s+", " ", m.group(2)).strip(" .,!?-")
        # Remove common search noise around the pair.
        left = re.sub(r"^(?:compare|comparison of)\s+", "", left).strip()
        if left and right:
            return {"mode": "explicit_pair", "targets": [left.title(), right.title()], "reason": "explicit vs/versus/against comparison"}

    # Semantic comparisons such as 'Peddi hit or flop'.
    for pattern, targets in COMPARISON_PATTERNS:
        if re.search(pattern, q, re.I):
            return {"mode": "semantic", "targets": [x[0] for x in targets], "aliases": {x[0]: x[1] for x in targets}, "reason": "comparison intent detected from the query"}
    return None


def detect_sides(query="", articles=None, max_sides=4):
    """Find the comparison targets. Prefer the user's requested comparison over article entities."""
    articles = articles or []
    requested = detect_requested_comparison(query)
    if requested:
        return requested["targets"][:max_sides]

    query_low = query.lower()
    found = []

    def present(alias, text):
        return bool(re.search(r"(?<![a-z])" + re.escape(alias.lower()) + r"(?![a-z])", text))

    # Only use known side/entity aliases when the query itself contains them.
    # Do NOT promote arbitrary countries/groups mentioned in article text into sides.
    for canonical, aliases in SIDE_ALIASES.items():
        if any(present(alias, query_low) for alias in aliases):
            found.append(canonical)

    explicit_pairs = re.findall(
        r"\b([A-Za-z][A-Za-z .&'-]{1,40})\s+(?:vs\.?|versus|against)\s+([A-Za-z][A-Za-z .&'-]{1,40})\b",
        query, flags=re.I,
    )
    for left, right in explicit_pairs:
        for item in (left, right):
            cleaned = re.sub(r"\s+", " ", item).strip(" .,-")
            if cleaned and cleaned.lower() not in {x.lower() for x in found}:
                found.append(_canonical_side_for_term(cleaned))
    return found[:max_sides]


def _sentence_split(text):
    # Keep punctuation-separated sentences; also split long feed snippets on ;
    # so a single huge RSS summary does not dilute local evidence.
    chunks = re.split(r"(?<=[.!?])\s+|\s*;\s*", text or "")
    return [s.strip() for s in chunks if s.strip()]


def _alias_pattern(alias):
    return r"(?<![a-z])" + re.escape(alias.lower()) + r"(?![a-z])"


def _find_mentions(sentence, aliases):
    out = []
    low = sentence.lower()
    for alias in sorted(aliases, key=len, reverse=True):
        for m in re.finditer(_alias_pattern(alias), low):
            out.append((m.start(), m.end(), alias))
    return sorted(out)


def _target_stance(text, canonical, aliases):
    """Score language specifically directed at one side, in [-1, 1]."""
    sentences = _sentence_split(text)
    raw = 0.0
    weight_total = 0.0
    mentions = 0
    evidence = []

    for sentence in sentences:
        low = sentence.lower()
        mentions_here = _find_mentions(sentence, aliases)
        if not mentions_here:
            continue
        mentions += len(mentions_here)
        toks = _tokenize(sentence)

        # Entity spans as token indexes. This handles both one-word and
        # multi-word aliases such as "United States" / "West Bank".
        spans = []
        for alias in aliases:
            at = low.find(alias.lower())
            while at >= 0:
                prefix = _tokenize(sentence[:at])
                ent = _tokenize(alias)
                spans.append((len(prefix), len(prefix) + max(len(ent), 1)))
                at = low.find(alias.lower(), at + 1)

        sentence_score = 0.0
        sentence_weight = 0.0
        signal_words = []

        for start, end in spans:
            center = (start + end - 1) / 2
            lo, hi = max(0, start - 9), min(len(toks), end + 9)
            window = toks[lo:hi]
            pos = sum(t in POSITIVE_WORDS or t in STANCE_POSITIVE_ACTIONS for t in window)
            neg = sum(t in NEGATIVE_WORDS or t in STANCE_NEGATIVE_ACTIONS for t in window)
            local = 0.0

            # Nearby descriptive language.
            if pos + neg:
                local += 0.42 * ((pos - neg) / (pos + neg))

            # Directional action pattern: SUBJECT + action + OBJECT.
            # This is the important part that prevents both sides from being
            # punished by a sentence such as "Russia attacked Ukraine".
            for ai, verb in enumerate(toks):
                if verb in STANCE_NEGATIVE_ACTIONS or verb in STANCE_POSITIVE_ACTIONS:
                    if abs(ai - center) <= 8:
                        side_before = ai > end - 1 and (ai - end) <= 5
                        side_after = ai < start and (start - ai) <= 5
                        if verb in STANCE_NEGATIVE_ACTIONS:
                            if side_before:
                                local -= 0.75
                                signal_words.append(verb)
                            elif side_after:
                                local += 0.75
                                signal_words.append(verb)
                        else:
                            if side_before:
                                local += 0.55
                                signal_words.append(verb)
                            elif side_after:
                                local -= 0.20
                                signal_words.append(verb)

            # Strong loaded/descriptive words immediately around the entity.
            loaded = [t for t in window if t in LOADED_WORDS]
            if loaded:
                # Loaded words are usually negative/accusatory in this
                # lexicon; keep their contribution smaller than actions.
                local -= min(0.25, 0.07 * len(loaded))
                signal_words.extend(loaded[:2])

            local = max(-1.0, min(1.0, local))
            sentence_score += local
            sentence_weight += 1.0

        if sentence_weight:
            local = sentence_score / sentence_weight
            weight = 1.0 + min(1.5, len(signal_words) * 0.15)
            raw += local * weight
            weight_total += weight
            if abs(local) >= 0.22 and len(evidence) < 4:
                evidence.append({
                    "text": sentence[:320],
                    "signal": "favorable" if local > 0 else "unfavorable",
                    "score": round(local, 2),
                })

    if mentions == 0 or weight_total == 0:
        return {"score": 0.0, "label": "not enough evidence", "mentions": 0, "evidence": []}

    score = max(-1.0, min(1.0, raw / weight_total))
    if score >= 0.16:
        label = "favorable"
    elif score <= -0.16:
        label = "unfavorable"
    else:
        label = "neutral / mixed"
    return {"score": round(score, 3), "label": label, "mentions": mentions, "evidence": evidence}



def summarize_people_perspectives(perspectives, query=""):
    """Summarize public reactions without presenting them as representative polling."""
    comments = []
    for item in perspectives or []:
        for c in item.get("comments", []):
            text = (c.get("text") or "").strip()
            if len(text) >= 12:
                comments.append({
                    **c,
                    "platform": item.get("platform", "Community"),
                    "community": item.get("community", ""),
                    "headline": item.get("headline", ""),
                    "url": item.get("url", ""),
                    "published_at": item.get("published_at", ""),
                })

    if not comments:
        return {
            "available": False,
            "summary": "No public community reactions were available for this search.",
            "platforms": [], "total_reactions": 0, "items": [],
            "method": "Public reactions are anecdotal signals, not a representative sample of public opinion."
        }

    # Use the same target-specific stance engine on individual reactions where possible.
    pseudo = [{"source": c["platform"], "headline": c["headline"], "text": c["text"]} for c in comments]
    stance = analyze_target_stance(pseudo, query)

    tone_counts = Counter()
    side_counts = Counter()
    enriched = []
    stance_rows = stance.get("results", []) if stance else []
    for idx, c in enumerate(comments):
        score = sentiment_score(c["text"])
        if score >= 0.15:
            tone = "positive"
        elif score <= -0.15:
            tone = "critical"
        else:
            tone = "mixed / neutral"
        tone_counts[tone] += 1
        side_label = "No clear side"
        if idx < len(stance_rows):
            row = stance_rows[idx]
            usable = [x for x in row.get("targets", []) if x.get("mentions", 0) > 0]
            if len(usable) >= 2:
                usable.sort(key=lambda x: x.get("score", 0), reverse=True)
                if usable[0]["score"] - usable[-1]["score"] >= 0.16:
                    side_label = usable[0]["target"]
            elif len(usable) == 1:
                side_label = f"mentions {usable[0]['target']}"
        if side_label != "No clear side":
            side_counts[side_label] += 1
        enriched.append({
            "platform": c["platform"], "community": c["community"],
            "text": c["text"][:500], "score": c.get("score", 0),
            "tone": tone, "side": side_label, "headline": c["headline"],
            "url": c["url"], "published_at": c["published_at"],
        })

    # Prefer high-engagement reactions for display, while retaining platform diversity.
    enriched.sort(key=lambda x: x.get("score", 0), reverse=True)
    selected = []
    platform_seen = Counter()
    for item in enriched:
        if len(selected) >= 10:
            break
        if platform_seen[item["platform"]] >= 5:
            continue
        selected.append(item)
        platform_seen[item["platform"]] += 1
    if len(selected) < min(10, len(enriched)):
        for item in enriched:
            if item not in selected:
                selected.append(item)
                if len(selected) >= 10:
                    break

    total = len(comments)
    dominant_tone = tone_counts.most_common(1)[0][0] if tone_counts else "mixed / neutral"
    dominant_side = side_counts.most_common(1)[0][0] if side_counts else "No clear side"
    if dominant_side != "No clear side":
        summary = f"Among the public reactions sampled here, the most common tone is {dominant_tone}, and the strongest detectable side-lean is toward {dominant_side}."
    else:
        summary = f"Among the public reactions sampled here, the most common tone is {dominant_tone}; the reactions do not contain enough target-specific language to identify a clear side-lean."

    return {
        "available": True,
        "summary": summary,
        "platforms": sorted({c["platform"] for c in comments}),
        "total_reactions": total,
        "tone_counts": dict(tone_counts),
        "side_counts": dict(side_counts),
        "items": selected,
        "method": "This is a sample of publicly visible Reddit posts/comments and YouTube comments. It is not a poll, not representative of the population, and may over-represent highly active users or communities."
    }

def analyze_target_stance(articles, query="", compare_targets=None, llm_intent=None, dimensions=None):
    """Compare arbitrary 2-4 targets and optionally return separate LLM dimensions."""
    def clean_targets(values):
        out=[]
        for x in values or []:
            x=re.sub(r"\s+", " ", str(x or "")).strip()
            if x and x.lower() not in {v.lower() for v in out}: out.append(x)
        return out[:4]

    sides = clean_targets(compare_targets) if isinstance(compare_targets, list) else []
    requested = detect_requested_comparison(query)
    if len(sides) < 2 and requested:
        sides=clean_targets(requested.get("targets", []))
    if len(sides) < 2 and llm_intent:
        sides=clean_targets(llm_intent.get("recommended_comparison", []))
        if len(sides)<2 and llm_intent.get("competitors"):
            sides=clean_targets(llm_intent.get("competitors", []))[:3]
    if len(sides) < 2:
        return {"sides": sides, "results": [], "available": False, "dimensions": [],
                "message": "No clear competing sides were found. Choose a comparison above."}

    alias_map = (requested or {}).get("aliases", {}) if requested else {}
    for side in sides:
        alias_map.setdefault(side, SIDE_ALIASES.get(side, [side.lower()]))

    def run_dimension(targets, name, reason=""):
        targets=clean_targets(targets)
        if len(targets)<2: return None
        rows=[]
        for article in articles:
            # Target stance is computed from article-body sentences only.
            text=(article.get("text") or "").strip()
            target_rows=[]
            for side in targets:
                target_rows.append({"target":side, **_target_stance(text, side, alias_map.get(side, [side.lower()]))})
            usable=[x for x in target_rows if x["mentions"]>0]
            ranked=sorted(usable,key=lambda x:x["score"],reverse=True)
            overall=(f"leans toward {ranked[0]['target']}" if len(ranked)>=2 and ranked[0]["score"]-ranked[-1]["score"]>=.12 else "mixed / no clear side") if len(ranked)>=2 else (f"evidence mainly about {ranked[0]['target']}" if ranked else "not enough evidence")
            rows.append({"source":article.get("source","Unknown source"),"headline":article.get("headline",""),"published_date":article.get("published_date",""),"targets":target_rows,"overall":overall})
        return {"name":name,"label":" vs ".join(targets),"reason":reason,"sides":targets,"results":rows}

    main=run_dimension(sides, "Overall side-by-side framing", "Selected event competitors")
    dims=[]
    raw_dims=dimensions or (llm_intent or {}).get("comparison_dimensions", [])
    for d in raw_dims:
        targets=clean_targets(d.get("targets", [])) if isinstance(d,dict) else []
        if len(targets)>=2:
            item=run_dimension(targets, d.get("name", "Framing dimension"), d.get("reason", ""))
            if item: dims.append(item)

    # Aggregate the per-article relative language signal into a media-framing share.
    totals={s:0.0 for s in sides}; evidence_count={s:0 for s in sides}
    for row in main["results"]:
        usable=[t for t in row["targets"] if t["mentions"]>0]
        if len(usable)<2: continue
        import math
        exps=[math.exp(float(t["score"])/.65) for t in usable]; denom=sum(exps) or 1
        for t,e in zip(usable,exps):
            totals[t["target"]]+=e/denom
            evidence_count[t["target"]]+=1
    total=sum(totals.values()) or 1
    overall_share=[{"target":s,"value":round(totals[s]/total*100,1),"evidence_articles":evidence_count[s]} for s in sides]

    return {"available":True,"sides":sides,"comparison_mode":(requested or {}).get("mode", "dynamic_event"),
            "comparison_reason":(requested or {}).get("reason", "Dynamic event comparison"),
            "results":main["results"],"dimensions":dims,"overall_share":overall_share,
            "message":"Scores are comparative language signals across the selected articles, not proof of an outlet's overall position or public opinion."}

